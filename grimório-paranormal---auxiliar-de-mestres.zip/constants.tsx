
import React from 'react';
import { Elemento } from './types';

export const ELEMENT_COLORS: Record<Elemento, string> = {
  [Elemento.SANGUE]: 'text-red-600',
  [Elemento.MORTE]: 'text-gray-500',
  [Elemento.CONHECIMENTO]: 'text-yellow-500',
  [Elemento.ENERGIA]: 'text-purple-500',
  [Elemento.MEDO]: 'text-zinc-300'
};

export const ELEMENT_BORDERS: Record<Elemento, string> = {
  [Elemento.SANGUE]: 'border-red-900',
  [Elemento.MORTE]: 'border-gray-800',
  [Elemento.CONHECIMENTO]: 'border-yellow-900',
  [Elemento.ENERGIA]: 'border-purple-900',
  [Elemento.MEDO]: 'border-zinc-800'
};

export const PERICIAS_LIST = [
  'Acrobacia', 'Adestramento', 'Artes', 'Atletismo', 'Atualidades', 
  'Ciências', 'Crime', 'Diplomacia', 'Enganação', 'Fortitude', 
  'Furtividade', 'Iniciativa', 'Intimidação', 'Intuição', 
  'Investigação', 'Luta', 'Medicina', 'Ocultismo', 'Percepção', 
  'Pilotagem', 'Pontaria', 'Profissão', 'Reflexos', 'Religião', 
  'Sobrevivência', 'Tática', 'Tecnologia', 'Vontade'
];
