
import React, { useState, useEffect } from 'react';
import Layout from './components/Layout';
import CreatureForm from './components/CreatureForm';
import RitualForm from './components/RitualForm';
import NPCForm from './components/NPCForm';
import VillainForm from './components/VillainForm';
import WeaponForm from './components/WeaponForm';
import DMScreen from './components/DMScreen';
import ToolsScreen from './components/ToolsScreen';
import CombatTracker from './components/CombatTracker';
import MissionManager from './components/MissionManager';
import LocationManager from './components/LocationManager';
import StatusReference from './components/StatusReference';
import ReferenceScreen from './components/ReferenceScreen';
import DiceRoller from './components/DiceRoller';
import { Criatura, LogDados, Ritual, NPC, Vilao, Elemento, Arma, TipoArma } from './types';
import { DEFAULT_RITUALS, DEFAULT_CREATURES, DEFAULT_NPCS, DEFAULT_WEAPONS, DEFAULT_VILLAINS } from './defaultData';
import { Skull, Plus, Search, Info, Trash2, Ghost, Flame, Users, LayoutDashboard, PenTool, Sword, Crosshair, Map, AlertTriangle, MapPin, GraduationCap } from 'lucide-react';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [creatures, setCreatures] = useState<Criatura[]>([]);
  const [rituals, setRituals] = useState<Ritual[]>([]);
  const [npcs, setNpcs] = useState<NPC[]>([]);
  const [villains, setVillains] = useState<Vilao[]>([]);
  const [weapons, setWeapons] = useState<Arma[]>([]);
  
  const [isAdding, setIsAdding] = useState(false);
  const [editingItem, setEditingItem] = useState<any>(null);
  const [diceLogs, setDiceLogs] = useState<LogDados[]>([]);

  // Carregamento inicial
  useEffect(() => {
    const sC = localStorage.getItem('paranormal_creatures');
    const sR = localStorage.getItem('paranormal_rituals');
    const sN = localStorage.getItem('paranormal_npcs');
    const sV = localStorage.getItem('paranormal_villains');
    const sW = localStorage.getItem('paranormal_weapons');

    if (sC) setCreatures(JSON.parse(sC)); else setCreatures(DEFAULT_CREATURES);
    if (sR) setRituals(JSON.parse(sR)); else setRituals(DEFAULT_RITUALS);
    if (sN) setNpcs(JSON.parse(sN)); else setNpcs(DEFAULT_NPCS);
    if (sW) setWeapons(JSON.parse(sW)); else setWeapons(DEFAULT_WEAPONS);
    if (sV) setVillains(JSON.parse(sV)); else setVillains(DEFAULT_VILLAINS);
  }, []);

  // Salvamento automático
  useEffect(() => {
    localStorage.setItem('paranormal_creatures', JSON.stringify(creatures));
    localStorage.setItem('paranormal_rituals', JSON.stringify(rituals));
    localStorage.setItem('paranormal_npcs', JSON.stringify(npcs));
    localStorage.setItem('paranormal_villains', JSON.stringify(villains));
    localStorage.setItem('paranormal_weapons', JSON.stringify(weapons));
  }, [creatures, rituals, npcs, villains, weapons]);

  const handleAddNew = () => {
    setEditingItem(null);
    setIsAdding(true);
  };

  const handleEdit = (item: any) => {
    setEditingItem(item);
    setIsAdding(true);
  };

  const saveEntity = (entity: any) => {
    const setters: any = { creatures: setCreatures, rituals: setRituals, npcs: setNpcs, villains: setVillains, weapons: setWeapons };
    const setter = setters[activeTab];
    if (setter) {
      setter((prev: any[]) => {
        const idx = prev.findIndex(e => e.id === entity.id);
        return idx >= 0 ? prev.map((e, i) => i === idx ? entity : e) : [...prev, entity];
      });
    }
    setIsAdding(false);
    setEditingItem(null);
  };

  const deleteEntity = (id: string, tab: string) => {
    if (!confirm('Eliminar permanentemente do registro?')) return;
    if (tab === 'creatures') setCreatures(creatures.filter(c => c.id !== id));
    if (tab === 'rituals') setRituals(rituals.filter(r => r.id !== id));
    if (tab === 'npcs') setNpcs(npcs.filter(n => n.id !== id));
    if (tab === 'villains') setVillains(villains.filter(v => v.id !== id));
    if (tab === 'weapons') setWeapons(weapons.filter(w => w.id !== id));
  };

  const renderContent = () => {
    if (isAdding) {
      return (
        <div className="space-y-6">
          <button onClick={() => setIsAdding(false)} className="text-zinc-500 hover:text-white flex items-center gap-2 font-bold group">
            <span className="group-hover:-translate-x-1 transition-transform">←</span> Voltar ao Registro
          </button>
          {activeTab === 'creatures' && <CreatureForm onSave={saveEntity} initialData={editingItem} />}
          {activeTab === 'rituals' && <RitualForm onSave={saveEntity} initialData={editingItem} />}
          {activeTab === 'npcs' && <NPCForm onSave={saveEntity} initialData={editingItem} />}
          {activeTab === 'villains' && <VillainForm onSave={saveEntity} initialData={editingItem} />}
          {activeTab === 'weapons' && <WeaponForm onSave={saveEntity} initialData={editingItem} />}
        </div>
      );
    }

    if (activeTab === 'dashboard') return <DMScreen />;
    if (activeTab === 'tools') return <ToolsScreen />;
    if (activeTab === 'combat') return <CombatTracker />;
    if (activeTab === 'missions') return <MissionManager />;
    if (activeTab === 'locations') return <LocationManager />;
    if (activeTab === 'status') return <StatusReference />;
    if (activeTab === 'guide') return <ReferenceScreen />;

    const getList = () => {
      const maps: any = { creatures, rituals, npcs, villains, weapons };
      return maps[activeTab] || [];
    };

    const list = getList();
    const icons: any = { creatures: Skull, rituals: Flame, npcs: Users, villains: Ghost, combat: Sword, weapons: Crosshair, missions: Map, status: AlertTriangle, locations: MapPin, guide: GraduationCap };
    const Icon = icons[activeTab] || Info;

    const getElementStyles = (elemento: Elemento) => {
      switch (elemento) {
        case Elemento.SANGUE: return 'border-red-900/40 text-red-500 bg-red-950/5';
        case Elemento.MORTE: return 'border-zinc-700 text-zinc-400 bg-zinc-900/50';
        case Elemento.CONHECIMENTO: return 'border-yellow-900/40 text-yellow-500 bg-yellow-950/5';
        case Elemento.ENERGIA: return 'border-purple-900/40 text-purple-500 bg-purple-950/5';
        case Elemento.MEDO: return 'border-zinc-100/20 text-zinc-100 bg-zinc-100/5';
        default: return 'border-zinc-800 text-zinc-500';
      }
    };

    return (
      <div className="space-y-8 pb-20">
        <div className="flex justify-between items-end border-b border-zinc-800 pb-8">
          <div>
            <h3 className="text-5xl font-cinzel text-zinc-100 font-bold capitalize flex items-center gap-6">
              <Icon className="text-red-700" size={40} /> {activeTab}
            </h3>
            <p className="text-zinc-500 text-sm mt-3 tracking-widest uppercase">Grimório Paranormal • Nível de Acesso: Mestre</p>
          </div>
          <button onClick={handleAddNew} className="bg-red-700 hover:bg-red-600 text-white px-8 py-4 rounded-2xl font-bold flex items-center gap-3 shadow-2xl shadow-red-900/30 transition-all active:scale-95 group">
            <Plus size={24} className="group-hover:rotate-90 transition-transform" /> Criar Registro
          </button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {list.map((item: any) => (
            <div key={item.id} className={`bg-zinc-900 border ${item.isBoss ? 'border-red-600 shadow-[0_0_20px_rgba(220,38,38,0.3)]' : (item.elemento ? getElementStyles(item.elemento) : 'border-zinc-800')} rounded-2xl p-8 hover:translate-y-[-8px] transition-all group relative overflow-hidden flex flex-col`}>
              <div className="flex justify-between mb-6">
                <h4 className="font-cinzel text-2xl text-zinc-100 font-bold truncate pr-4">{item.nome}</h4>
                <div className="flex gap-3">
                  <button onClick={() => handleEdit(item)} className="text-zinc-600 hover:text-white transition-colors"><PenTool size={18} /></button>
                  <button onClick={() => deleteEntity(item.id, activeTab)} className="text-zinc-600 hover:text-red-500 transition-colors"><Trash2 size={18} /></button>
                </div>
              </div>
              <div className="text-[10px] font-bold uppercase mb-4 tracking-[0.2em] bg-black/40 inline-block px-3 py-1.5 rounded-full border border-zinc-800 w-fit">
                {activeTab === 'creatures' ? `${item.elemento} • VD ${item.vd}` : 
                 activeTab === 'rituals' ? `${item.elemento} • ${item.circulo}º Círculo` : 
                 activeTab === 'weapons' ? `${item.tipo} • Cat ${item.categoria}` :
                 activeTab === 'villains' ? `NEX ${item.nex}% • ${item.classe}` :
                 item.funcao}
              </div>
              <p className="text-sm text-zinc-400 italic line-clamp-4 leading-relaxed mb-8 flex-1">
                {item.descricao || item.efeito || item.personalidade || "Registro arquivado."}
              </p>
              <button onClick={() => handleEdit(item)} className="w-full py-3 bg-zinc-800 hover:bg-red-700 hover:text-white text-zinc-400 rounded-xl text-xs font-bold uppercase tracking-widest transition-all">
                Abrir Ficha
              </button>
            </div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <Layout activeTab={activeTab} setActiveTab={setActiveTab}>
      {renderContent()}
      <DiceRoller logs={diceLogs} onRoll={(log) => setDiceLogs(prev => [log, ...prev].slice(0, 50))} />
    </Layout>
  );
};

export default App;
