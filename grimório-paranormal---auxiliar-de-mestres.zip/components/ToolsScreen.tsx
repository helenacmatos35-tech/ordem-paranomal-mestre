
import React, { useState } from 'react';
import { Download, Sparkles, Map, Gift, Skull, Flame, Ghost, BrainCircuit, UserPlus, FileText } from 'lucide-react';
import { Elemento } from '../types';
import { gerarCenaParanormal, gerarItemAmaldicoado, descreverAmbiente, gerarIdentidadeVitima } from '../geminiService';

const ToolsScreen: React.FC = () => {
  const [output, setOutput] = useState('');
  const [loading, setLoading] = useState(false);
  const [activeGen, setActiveGen] = useState<'cena' | 'item' | 'ambiente' | 'vitima'>('cena');

  const exportData = () => {
    const data = {
      creatures: JSON.parse(localStorage.getItem('paranormal_creatures') || '[]'),
      rituals: JSON.parse(localStorage.getItem('paranormal_rituals') || '[]'),
      npcs: JSON.parse(localStorage.getItem('paranormal_npcs') || '[]'),
      villains: JSON.parse(localStorage.getItem('paranormal_villains') || '[]'),
      locations: JSON.parse(localStorage.getItem('paranormal_locations') || '[]'),
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `grimorio_paranormal_full_backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
  };

  const handleAction = async (action: string, param?: any) => {
    setLoading(true);
    let result = '';
    if (action === 'cena') {
      setActiveGen('cena');
      result = await gerarCenaParanormal(param as Elemento);
    } else if (action === 'item') {
      setActiveGen('item');
      result = await gerarItemAmaldicoado(param as Elemento);
    } else if (action === 'ambiente') {
      setActiveGen('ambiente');
      result = await descreverAmbiente(param as string);
    } else if (action === 'vitima') {
      setActiveGen('vitima');
      result = await gerarIdentidadeVitima();
    }
    setOutput(result || '');
    setLoading(false);
  };

  return (
    <div className="space-y-12">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-2xl shadow-xl flex flex-col justify-between">
          <div>
            <h3 className="font-cinzel text-lg text-zinc-100 font-bold flex items-center gap-3 mb-4">
              <Sparkles size={18} className="text-yellow-500" /> Horror IA
            </h3>
            <div className="grid grid-cols-1 gap-2">
              <button onClick={() => handleAction('cena', Elemento.SANGUE)} className="bg-red-900/10 text-red-500 p-2 rounded text-[10px] font-bold border border-red-900/20 hover:bg-red-900/30 transition-all uppercase">Cena de Sangue</button>
              <button onClick={() => handleAction('cena', Elemento.MORTE)} className="bg-zinc-800 text-zinc-400 p-2 rounded text-[10px] font-bold border border-zinc-700 hover:bg-zinc-700 transition-all uppercase">Cena de Morte</button>
            </div>
          </div>
        </div>

        <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-2xl shadow-xl flex flex-col justify-between">
          <div>
            <h3 className="font-cinzel text-lg text-zinc-100 font-bold flex items-center gap-3 mb-4">
              <UserPlus size={18} className="text-blue-500" /> Identidades
            </h3>
            <p className="text-zinc-500 text-[10px] mb-4">Gere vítimas e transeuntes com histórico rápido.</p>
            <button onClick={() => handleAction('vitima')} className="w-full bg-blue-900/20 text-blue-400 p-3 rounded-xl text-xs font-bold border border-blue-800/30 hover:bg-blue-800/40 transition-all">Gerar Vítima</button>
          </div>
        </div>

        <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-2xl shadow-xl flex flex-col justify-between">
          <div>
            <h3 className="font-cinzel text-lg text-zinc-100 font-bold flex items-center gap-3 mb-4">
              <Gift size={18} className="text-red-700" /> Relíquias
            </h3>
            <button onClick={() => handleAction('item', Elemento.MEDO)} className="w-full bg-red-900/20 text-red-400 p-3 rounded-xl text-xs font-bold border border-red-800/30 hover:bg-red-800/40">Objeto Amaldiçoado</button>
          </div>
        </div>

        <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-2xl shadow-xl flex flex-col justify-between">
          <div>
            <h3 className="font-cinzel text-lg text-zinc-100 font-bold flex items-center gap-3 mb-4">
              <Map size={18} className="text-purple-500" /> Ambientes
            </h3>
            <button onClick={() => handleAction('ambiente', 'Laboratório')} className="w-full bg-purple-900/20 text-purple-400 p-3 rounded-xl text-xs font-bold border border-purple-800/30">Descrever Local</button>
          </div>
        </div>
      </div>

      {loading && (
        <div className="bg-black/40 border border-red-900/30 p-12 rounded-2xl flex flex-col items-center justify-center gap-4 animate-pulse">
          <BrainCircuit className="text-red-700" size={48} />
          <p className="font-cinzel text-red-500 uppercase tracking-[0.3em]">O Outro Lado está respondendo...</p>
        </div>
      )}

      {output && !loading && (
        <div className={`bg-black/60 border-l-4 p-8 rounded-r-2xl animate-fadeIn ${activeGen === 'vitima' ? 'border-blue-700' : 'border-red-700'}`}>
          <div className="flex justify-between items-start mb-6">
            <span className="text-[10px] uppercase font-bold text-zinc-500 tracking-widest bg-zinc-800 px-3 py-1 rounded">
              {activeGen === 'vitima' ? 'Identidade Paranormal' : 'Manifestação IA'}
            </span>
            <button onClick={() => setOutput('')} className="text-zinc-600 hover:text-white transition-colors">✕</button>
          </div>
          <div className="text-zinc-200 font-serif leading-relaxed italic whitespace-pre-wrap text-lg">
            {output}
          </div>
        </div>
      )}

      <div className="bg-zinc-900 border border-zinc-800 p-8 rounded-2xl shadow-xl">
        <h3 className="font-cinzel text-xl text-zinc-100 font-bold flex items-center gap-3 mb-4">
          <Download className="text-zinc-400" /> Exportação Completa
        </h3>
        <p className="text-zinc-500 text-sm mb-6">Backup de todos os dados: Criaturas, Vilões, NPCs, Rituais e Localidades.</p>
        <button onClick={exportData} className="w-full bg-zinc-800 hover:bg-zinc-700 text-white font-bold py-4 rounded-xl border border-zinc-700 transition-all flex items-center justify-center gap-2">
           Baixar Grimório Completo (.json)
        </button>
      </div>
    </div>
  );
};

export default ToolsScreen;
