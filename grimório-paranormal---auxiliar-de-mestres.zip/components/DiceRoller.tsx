
import React, { useState, useEffect } from 'react';
import { Dices, Trash2, ShieldAlert } from 'lucide-react';
import { LogDados } from '../types';

interface DiceRollerProps {
  onRoll: (log: LogDados) => void;
  logs: LogDados[];
}

const DiceRoller: React.FC<DiceRollerProps> = ({ onRoll, logs }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [numDice, setNumDice] = useState(1);
  const [diceType, setDiceType] = useState(20);
  const [modifier, setModifier] = useState(0);
  const [isSecret, setIsSecret] = useState(false);

  const rollDice = () => {
    let rolls: number[] = [];
    for (let i = 0; i < numDice; i++) {
      rolls.push(Math.floor(Math.random() * diceType) + 1);
    }
    
    // Ordem Paranormal logic: If d20, usually take the highest.
    // However, the standard roller will sum or list depending on user expectation.
    // For Ordem (d20), we usually roll multiple and keep the highest.
    const result = diceType === 20 ? Math.max(...rolls) + modifier : rolls.reduce((a, b) => a + b, 0) + modifier;
    
    const log: LogDados = {
      timestamp: new Date().toLocaleTimeString(),
      formula: `${numDice}d${diceType}${modifier >= 0 ? '+' : ''}${modifier}`,
      resultado: result,
      detalhes: `Rolagens: [${rolls.join(', ')}] ${modifier !== 0 ? `Mod: ${modifier}` : ''}`,
      secret: isSecret
    };
    
    onRoll(log);
  };

  return (
    <div className={`fixed bottom-6 right-6 z-50 transition-all duration-300 ${isOpen ? 'w-80' : 'w-16'}`}>
      {!isOpen ? (
        <button 
          onClick={() => setIsOpen(true)}
          className="w-16 h-16 bg-red-700 hover:bg-red-600 rounded-full flex items-center justify-center shadow-lg shadow-red-900/20 border-2 border-red-500/50"
        >
          <Dices className="text-white" size={32} />
        </button>
      ) : (
        <div className="bg-zinc-900 border border-red-900/50 rounded-lg shadow-2xl overflow-hidden flex flex-col h-[500px]">
          <div className="bg-red-950/40 p-3 flex justify-between items-center border-b border-red-900/30">
            <h3 className="font-cinzel text-red-100 flex items-center gap-2">
              <Dices size={18} /> Dados Paranormais
            </h3>
            <button onClick={() => setIsOpen(false)} className="text-zinc-400 hover:text-white">✕</button>
          </div>
          
          <div className="p-4 space-y-4 bg-zinc-900/50">
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-xs text-zinc-500 uppercase font-bold">Qtd</label>
                <input 
                  type="number" 
                  value={numDice}
                  onChange={(e) => setNumDice(parseInt(e.target.value) || 1)}
                  className="w-full bg-zinc-800 border border-zinc-700 rounded p-2 text-white focus:outline-none focus:border-red-600"
                />
              </div>
              <div>
                <label className="text-xs text-zinc-500 uppercase font-bold">Dado</label>
                <select 
                  value={diceType}
                  onChange={(e) => setDiceType(parseInt(e.target.value))}
                  className="w-full bg-zinc-800 border border-zinc-700 rounded p-2 text-white focus:outline-none focus:border-red-600"
                >
                  {[4, 6, 8, 10, 12, 20, 100].map(d => <option key={d} value={d}>d{d}</option>)}
                </select>
              </div>
            </div>
            
            <div>
              <label className="text-xs text-zinc-500 uppercase font-bold">Bônus/Penalidade</label>
              <input 
                type="number" 
                value={modifier}
                onChange={(e) => setModifier(parseInt(e.target.value) || 0)}
                className="w-full bg-zinc-800 border border-zinc-700 rounded p-2 text-white focus:outline-none focus:border-red-600"
              />
            </div>

            <div className="flex items-center gap-2">
              <input 
                type="checkbox" 
                id="secret-roll"
                checked={isSecret}
                onChange={(e) => setIsSecret(e.target.checked)}
                className="accent-red-600"
              />
              <label htmlFor="secret-roll" className="text-sm text-zinc-300 flex items-center gap-1 cursor-pointer">
                <ShieldAlert size={14} className="text-red-500" /> Rolagem Oculta
              </label>
            </div>

            <button 
              onClick={rollDice}
              className="w-full bg-red-700 hover:bg-red-600 text-white font-bold py-2 rounded transition-colors"
            >
              Rolar Dado
            </button>
          </div>

          <div className="flex-1 p-3 overflow-y-auto paranormal-scroll bg-black/40">
            <h4 className="text-xs text-zinc-600 uppercase mb-2 border-b border-zinc-800 pb-1">Histórico</h4>
            <div className="space-y-2">
              {logs.map((log, idx) => (
                <div key={idx} className={`p-2 rounded text-xs border ${log.secret ? 'bg-red-950/10 border-red-900/30' : 'bg-zinc-800/30 border-zinc-700'}`}>
                  <div className="flex justify-between text-zinc-500 mb-1">
                    <span>{log.formula}</span>
                    <span>{log.timestamp}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-zinc-400 truncate max-w-[150px]">{log.detalhes}</span>
                    <span className={`font-bold text-lg ${log.secret ? 'text-red-400' : 'text-zinc-100'}`}>
                      {log.resultado}
                    </span>
                  </div>
                </div>
              ))}
              {logs.length === 0 && <p className="text-center text-zinc-600 mt-4 italic">Nenhuma rolagem ainda.</p>}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DiceRoller;
