
import React, { useState } from 'react';
import { Elemento, Vilao, Classe, Atributos } from '../types';
import { Save, Ghost, Skull, Zap, Brain, Shield, Swords } from 'lucide-react';

interface VillainFormProps {
  onSave: (vilao: Vilao) => void;
  initialData?: Vilao;
}

const VillainForm: React.FC<VillainFormProps> = ({ onSave, initialData }) => {
  const [formData, setFormData] = useState<Vilao>(initialData || {
    id: Math.random().toString(36).substr(2, 9),
    nome: '',
    elemento: Elemento.MORTE,
    vd: 40,
    nex: 35,
    classe: Classe.OCULTISTA,
    trilha: '',
    vida: 80,
    defesa: 20,
    resistencias: '',
    sanidade: 40,
    atributos: { FOR: 1, AGI: 2, INT: 4, PRE: 3, VIG: 2 },
    pericias: [],
    ataques: [],
    rituais: [],
    objetosAmaldiçoados: '',
    fraquezas: '',
    habilidades: '',
    passivas: '',
    descricao: '',
    isBoss: false
  });

  const handleAttrChange = (attr: keyof Atributos, val: number) => {
    setFormData(prev => ({ ...prev, atributos: { ...prev.atributos, [attr]: val } }));
  };

  return (
    <div className={`bg-zinc-900 border ${formData.isBoss ? 'border-red-600 shadow-[0_0_20px_rgba(220,38,38,0.2)]' : 'border-zinc-800'} rounded-xl overflow-hidden transition-all`}>
      <div className={`${formData.isBoss ? 'bg-red-950/40' : 'bg-zinc-800/40'} p-6 border-b border-zinc-800 flex justify-between items-center`}>
        <h3 className="font-cinzel text-2xl text-red-500 font-bold flex items-center gap-3">
          <Ghost className={formData.isBoss ? 'animate-pulse' : ''} /> {formData.isBoss ? 'ENTIDADE ANTAGONISTA' : 'VILÃO PARANORMAL'}
        </h3>
        <div className="flex items-center gap-4">
          <label className="flex items-center gap-2 cursor-pointer bg-black/40 px-3 py-1 rounded-full border border-red-900/50">
            <input type="checkbox" checked={formData.isBoss} onChange={e => setFormData({...formData, isBoss: e.target.checked})} className="accent-red-600" />
            <span className="text-[10px] font-bold text-red-500 uppercase">Modo Boss</span>
          </label>
          <button onClick={() => onSave(formData)} className="bg-red-700 hover:bg-red-600 text-white px-6 py-2 rounded-lg font-bold flex items-center gap-2">
            <Save size={18} /> Salvar Vilão
          </button>
        </div>
      </div>

      <div className="p-8 grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="space-y-4">
          <div>
            <label className="text-xs text-zinc-500 uppercase font-bold mb-1 block">Nome do Vilão</label>
            <input value={formData.nome} onChange={e => setFormData({...formData, nome: e.target.value})} className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-zinc-100 outline-none focus:border-red-600" />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-xs text-zinc-500 uppercase font-bold mb-1 block">NEX</label>
              <input type="number" value={formData.nex} onChange={e => setFormData({...formData, nex: parseInt(e.target.value) || 0})} className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-2 text-zinc-100" />
            </div>
            <div>
              <label className="text-xs text-zinc-500 uppercase font-bold mb-1 block">VD</label>
              <input type="number" value={formData.vd} onChange={e => setFormData({...formData, vd: parseInt(e.target.value) || 0})} className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-2 text-zinc-100" />
            </div>
          </div>
          <div>
            <label className="text-xs text-zinc-500 uppercase font-bold mb-1 block">Classe</label>
            <select value={formData.classe} onChange={e => setFormData({...formData, classe: e.target.value as Classe})} className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-zinc-100">
              {Object.values(Classe).map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
        </div>

        <div className="md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-black/40 p-4 rounded-xl border border-zinc-800">
            <h4 className="font-cinzel text-zinc-400 mb-4 flex items-center gap-2 border-b border-zinc-800 pb-2"><Brain size={16}/> Atributos</h4>
            <div className="grid grid-cols-5 gap-2">
              {Object.entries(formData.atributos).map(([k, v]) => (
                <div key={k} className="text-center">
                  <div className="text-[10px] text-zinc-600 font-bold">{k}</div>
                  <input type="number" value={v} onChange={e => handleAttrChange(k as any, parseInt(e.target.value) || 0)} className="w-full bg-zinc-900 border border-zinc-700 rounded text-center text-red-500 font-bold p-1 outline-none" />
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
             <div className="bg-zinc-950 p-3 rounded border border-zinc-800">
                <label className="text-[10px] text-zinc-600 uppercase font-bold flex items-center gap-1"><Shield size={10}/> Vida</label>
                <input type="number" value={formData.vida} onChange={e => setFormData({...formData, vida: parseInt(e.target.value) || 0})} className="w-full bg-transparent text-xl font-bold text-red-500 outline-none" />
             </div>
             <div className="bg-zinc-950 p-3 rounded border border-zinc-800">
                <label className="text-[10px] text-zinc-600 uppercase font-bold flex items-center gap-1"><Zap size={10}/> Sanidade</label>
                <input type="number" value={formData.sanidade} onChange={e => setFormData({...formData, sanidade: parseInt(e.target.value) || 0})} className="w-full bg-transparent text-xl font-bold text-blue-500 outline-none" />
             </div>
          </div>
        </div>

        <div className="md:col-span-3 grid grid-cols-1 md:grid-cols-2 gap-8">
           <div className="space-y-4">
              <label className="text-xs text-zinc-500 uppercase font-bold flex items-center gap-2"><Swords size={14}/> Objetos & Rituais</label>
              <textarea rows={4} value={formData.objetosAmaldiçoados} onChange={e => setFormData({...formData, objetosAmaldiçoados: e.target.value})} placeholder="Itens que carrega ou rituais conhecidos..." className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-zinc-300 text-sm outline-none resize-none" />
           </div>
           <div className="space-y-4">
              <label className="text-xs text-zinc-500 uppercase font-bold flex items-center gap-2 text-yellow-600"><Skull size={14}/> Fraquezas & Obsessões</label>
              <textarea rows={4} value={formData.fraquezas} onChange={e => setFormData({...formData, fraquezas: e.target.value})} placeholder="O que pode detê-lo definitivamente?..." className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-zinc-300 text-sm outline-none resize-none" />
           </div>
        </div>
      </div>
    </div>
  );
};

export default VillainForm;
