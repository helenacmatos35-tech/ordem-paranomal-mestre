
import React, { useState } from 'react';
import { OFFICIAL_CONDITIONS } from '../defaultData';
import { Search, AlertTriangle, Info } from 'lucide-react';

const StatusReference: React.FC = () => {
  const [search, setSearch] = useState('');

  const filtered = OFFICIAL_CONDITIONS.filter(c => 
    c.nome.toLowerCase().includes(search.toLowerCase()) || 
    c.efeito.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-8 shadow-2xl">
      <div className="flex flex-col md:flex-row justify-between items-center gap-4 mb-8">
        <h3 className="font-cinzel text-2xl text-yellow-600 font-bold flex items-center gap-3">
          <AlertTriangle /> Biblioteca de Condições
        </h3>
        <div className="relative w-full md:w-80">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" size={18} />
          <input 
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Buscar condição (ex: Cego)..."
            className="w-full bg-zinc-950 border border-zinc-800 rounded-full pl-10 pr-4 py-2 text-sm text-white outline-none focus:border-yellow-900"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 max-h-[500px] overflow-y-auto pr-4 paranormal-scroll">
        {filtered.map(c => (
          <div key={c.nome} className="bg-black/30 border border-zinc-800 rounded-xl p-5 hover:border-yellow-900/30 transition-all group">
            <div className="flex items-center justify-between mb-3">
               <h4 className="font-bold text-yellow-500 text-lg">{c.nome}</h4>
               <Info size={16} className="text-zinc-700 group-hover:text-yellow-700" />
            </div>
            <p className="text-xs text-zinc-300 font-bold mb-2 uppercase tracking-tighter opacity-80">{c.efeito}</p>
            <p className="text-xs text-zinc-500 italic leading-relaxed">{c.penalidade}</p>
          </div>
        ))}
        {filtered.length === 0 && (
          <div className="col-span-full py-20 text-center text-zinc-600 italic">Nenhuma condição encontrada. O Outro Lado não revela nada.</div>
        )}
      </div>
    </div>
  );
};

export default StatusReference;
