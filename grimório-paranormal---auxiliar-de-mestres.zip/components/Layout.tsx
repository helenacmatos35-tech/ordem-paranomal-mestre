
import React from 'react';
import { Skull, Ghost, Book, Users, ScrollText, PenTool, LayoutDashboard, Sword, Crosshair, Map, AlertTriangle, MapPin, GraduationCap } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const Layout: React.FC<LayoutProps> = ({ children, activeTab, setActiveTab }) => {
  const navItems = [
    { id: 'dashboard', label: 'Início', icon: LayoutDashboard },
    { id: 'missions', label: 'Missões', icon: Map },
    { id: 'locations', label: 'Locais', icon: MapPin },
    { id: 'combat', label: 'Combate', icon: Sword },
    { id: 'status', label: 'Status', icon: AlertTriangle },
    { id: 'guide', label: 'Guia', icon: GraduationCap },
    { id: 'creatures', label: 'Criaturas', icon: Skull },
    { id: 'weapons', label: 'Armas', icon: Crosshair },
    { id: 'villains', label: 'Vilões', icon: Ghost },
    { id: 'npcs', label: 'NPCs', icon: Users },
    { id: 'rituals', label: 'Rituais', icon: ScrollText },
    { id: 'tools', label: 'Ferramentas', icon: PenTool },
  ];

  return (
    <div className="flex h-screen bg-zinc-950 overflow-hidden">
      {/* Sidebar */}
      <aside className="w-20 md:w-64 bg-zinc-900 border-r border-red-900/20 flex flex-col shadow-[10px_0_30px_rgba(0,0,0,0.5)] z-20">
        <div className="p-6 border-b border-red-900/20 flex items-center gap-3">
          <div className="bg-red-700 p-2 rounded-lg shadow-lg shadow-red-900/20">
            <Book className="text-white" size={24} />
          </div>
          <h1 className="hidden md:block font-cinzel text-xl text-red-500 font-bold tracking-widest">
            GRIMÓRIO
          </h1>
        </div>
        
        <nav className="flex-1 mt-6 px-3 space-y-1 overflow-y-auto paranormal-scroll">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-4 px-4 py-2 rounded-lg transition-all duration-200 group ${
                activeTab === item.id 
                ? 'bg-red-900/20 text-red-500 border border-red-900/30' 
                : 'text-zinc-500 hover:bg-zinc-800 hover:text-zinc-300'
              }`}
            >
              <item.icon size={20} className={activeTab === item.id ? 'text-red-500' : 'group-hover:text-red-400'} />
              <span className="hidden md:block font-medium text-sm">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="p-6 border-t border-red-900/10 text-center">
          <p className="hidden md:block text-[10px] text-zinc-600 uppercase tracking-tighter">
            Sistema Oficial Ordem Paranormal
          </p>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden relative">
        <header className="h-16 bg-zinc-900/50 backdrop-blur-md border-b border-zinc-800 px-8 flex items-center justify-between z-10">
          <h2 className="font-cinzel text-zinc-300 text-lg uppercase tracking-widest">
            {navItems.find(n => n.id === activeTab)?.label}
          </h2>
          <div className="flex items-center gap-4">
             <span className="hidden sm:block text-[10px] text-zinc-500 italic uppercase tracking-widest">Membrana: Estável</span>
             <div className="w-8 h-8 rounded-full bg-red-900/40 border border-red-700/50 flex items-center justify-center text-red-400 font-bold text-xs">
               M
             </div>
          </div>
        </header>

        <section className="flex-1 overflow-y-auto paranormal-scroll p-4 md:p-8 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] bg-fixed relative">
          <div className="max-w-6xl mx-auto animate-fadeIn pb-20">
            {children}
          </div>
        </section>
      </main>
    </div>
  );
};

export default Layout;
