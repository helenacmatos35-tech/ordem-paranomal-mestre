import React, { useState } from 'react';
import { Elemento, Criatura, Atributos } from '../types';
import { ELEMENT_COLORS, PERICIAS_LIST } from '../constants';
// Fixed imports to include Skull and removed the duplicate from the bottom of the file
import { Sparkles, Save, Shield, Swords, BrainCircuit, Skull } from 'lucide-react';
import { gerarDescricaoCriatura } from '../geminiService';

interface CreatureFormProps {
  onSave: (creature: Criatura) => void;
  initialData?: Criatura;
}

const CreatureForm: React.FC<CreatureFormProps> = ({ onSave, initialData }) => {
  const [formData, setFormData] = useState<Criatura>(initialData || {
    id: Math.random().toString(36).substr(2, 9),
    nome: '',
    elemento: Elemento.SANGUE,
    vd: 20,
    vida: 40,
    defesa: 15,
    resistencias: '',
    atributos: { FOR: 2, AGI: 2, INT: 1, PRE: 1, VIG: 2 },
    pericias: [],
    ataques: [],
    habilidades: '',
    passivas: '',
    descricao: ''
  });

  const [isGenerating, setIsGenerating] = useState(false);

  const handleAttrChange = (attr: keyof Atributos, val: number) => {
    setFormData(prev => ({
      ...prev,
      atributos: { ...prev.atributos, [attr]: val }
    }));
  };

  const handleGenerateDescription = async () => {
    if (!formData.nome) return alert('Dê um nome à criatura primeiro!');
    setIsGenerating(true);
    try {
      const desc = await gerarDescricaoCriatura(formData.nome, formData.elemento, formData.vd);
      setFormData(prev => ({ ...prev, descricao: desc || '' }));
    } catch (e) {
      console.error(e);
    } finally {
      setIsGenerating(false);
    }
  };

  const addAtaque = () => {
    setFormData(prev => ({
      ...prev,
      ataques: [...prev.ataques, { nome: 'Novo Ataque', teste: '2d20+5', dano: '2d6+2', alcance: 'Curto', tipo: 'Corte' }]
    }));
  };

  const updateAtaque = (index: number, field: string, val: string) => {
    const newAtaques = [...formData.ataques];
    newAtaques[index] = { ...newAtaques[index], [field]: val };
    setFormData(prev => ({ ...prev, ataques: newAtaques }));
  };

  return (
    <div className="bg-zinc-900/80 border border-zinc-800 rounded-xl overflow-hidden shadow-2xl">
      <div className="bg-red-950/20 p-6 border-b border-red-900/20 flex justify-between items-center">
        <h3 className="font-cinzel text-2xl text-red-500 font-bold tracking-widest flex items-center gap-3">
          <Skull className="text-red-600" /> Registro do Outro Lado
        </h3>
        <button 
          onClick={() => onSave(formData)}
          className="bg-red-700 hover:bg-red-600 text-white px-6 py-2 rounded-lg font-bold flex items-center gap-2 transition-all shadow-lg shadow-red-900/30"
        >
          <Save size={18} /> Salvar Ficha
        </button>
      </div>

      <div className="p-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Coluna 1: Básico & Atributos */}
        <div className="space-y-6">
          <div className="space-y-4">
            <div>
              <label className="text-xs text-zinc-500 uppercase font-bold tracking-widest mb-1 block">Nome da Criatura</label>
              <input 
                value={formData.nome}
                onChange={e => setFormData({...formData, nome: e.target.value})}
                placeholder="Ex: O Degolador"
                className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-zinc-100 focus:border-red-600 outline-none"
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-xs text-zinc-500 uppercase font-bold tracking-widest mb-1 block">Elemento Principal</label>
                <select 
                  value={formData.elemento}
                  onChange={e => setFormData({...formData, elemento: e.target.value as Elemento})}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-zinc-100 outline-none focus:border-red-600"
                >
                  {Object.values(Elemento).map(el => <option key={el} value={el}>{el}</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs text-zinc-500 uppercase font-bold tracking-widest mb-1 block">VD (Valor Desafio)</label>
                <input 
                  type="number"
                  value={formData.vd}
                  onChange={e => setFormData({...formData, vd: parseInt(e.target.value) || 0})}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-zinc-100 outline-none focus:border-red-600"
                />
              </div>
            </div>
          </div>

          <div className="bg-black/40 p-6 rounded-xl border border-zinc-800">
            <h4 className="font-cinzel text-zinc-400 mb-6 text-center border-b border-zinc-800 pb-2">Atributos</h4>
            <div className="grid grid-cols-5 gap-2">
              {Object.entries(formData.atributos).map(([key, val]) => (
                <div key={key} className="text-center">
                  <div className="text-[10px] text-zinc-600 font-bold mb-1">{key}</div>
                  <input 
                    type="number"
                    value={val}
                    onChange={e => handleAttrChange(key as keyof Atributos, parseInt(e.target.value) || 0)}
                    className="w-full bg-zinc-900 border border-zinc-700 rounded-md p-1 text-center text-red-500 font-bold focus:border-red-500 outline-none"
                  />
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-zinc-950 p-4 rounded-lg border border-zinc-800 flex items-center gap-4">
              <div className="bg-red-900/20 p-2 rounded-full"><Shield className="text-red-500" size={20} /></div>
              <div>
                <label className="text-[10px] text-zinc-600 uppercase font-bold">Vida</label>
                <input 
                  type="number"
                  value={formData.vida}
                  onChange={e => setFormData({...formData, vida: parseInt(e.target.value) || 0})}
                  className="w-full bg-transparent text-xl font-bold text-white outline-none"
                />
              </div>
            </div>
            <div className="bg-zinc-950 p-4 rounded-lg border border-zinc-800 flex items-center gap-4">
              <div className="bg-blue-900/20 p-2 rounded-full"><Shield className="text-blue-500" size={20} /></div>
              <div>
                <label className="text-[10px] text-zinc-600 uppercase font-bold">Defesa</label>
                <input 
                  type="number"
                  value={formData.defesa}
                  onChange={e => setFormData({...formData, defesa: parseInt(e.target.value) || 0})}
                  className="w-full bg-transparent text-xl font-bold text-white outline-none"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Coluna 2: Ataques & Habilidades */}
        <div className="space-y-6 lg:col-span-2">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
               <h4 className="font-cinzel text-zinc-400 flex items-center gap-2"><Swords size={20} className="text-red-600"/> Ações & Ataques</h4>
               <button onClick={addAtaque} className="text-xs text-red-500 hover:text-red-400 font-bold uppercase tracking-wider underline">Adicionar Ataque</button>
            </div>
            <div className="space-y-3">
              {formData.ataques.map((atk, idx) => (
                <div key={idx} className="bg-zinc-950/60 p-4 rounded-lg border border-zinc-800/50 grid grid-cols-5 gap-3">
                  <input placeholder="Nome" value={atk.nome} onChange={e => updateAtaque(idx, 'nome', e.target.value)} className="col-span-1 bg-zinc-900 border border-zinc-800 rounded p-1 text-sm text-zinc-300"/>
                  <input placeholder="Teste" value={atk.teste} onChange={e => updateAtaque(idx, 'teste', e.target.value)} className="bg-zinc-900 border border-zinc-800 rounded p-1 text-sm text-zinc-300"/>
                  <input placeholder="Dano" value={atk.dano} onChange={e => updateAtaque(idx, 'dano', e.target.value)} className="bg-zinc-900 border border-zinc-800 rounded p-1 text-sm text-zinc-300"/>
                  <input placeholder="Alcance" value={atk.alcance} onChange={e => updateAtaque(idx, 'alcance', e.target.value)} className="bg-zinc-900 border border-zinc-800 rounded p-1 text-sm text-zinc-300"/>
                  <button onClick={() => setFormData(prev => ({...prev, ataques: prev.ataques.filter((_, i) => i !== idx)}))} className="text-zinc-600 hover:text-red-500">✕</button>
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-xs text-zinc-500 uppercase font-bold tracking-widest mb-1 block">Habilidades Especiais</label>
              <textarea 
                rows={4}
                value={formData.habilidades}
                onChange={e => setFormData({...formData, habilidades: e.target.value})}
                placeholder="Descreva as habilidades ativas..."
                className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-zinc-300 text-sm focus:border-red-600 outline-none resize-none"
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs text-zinc-500 uppercase font-bold tracking-widest mb-1 block">Passivas Paranormais</label>
              <textarea 
                rows={4}
                value={formData.passivas}
                onChange={e => setFormData({...formData, passivas: e.target.value})}
                placeholder="Resistências, percepção às cegas, etc..."
                className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-zinc-300 text-sm focus:border-red-600 outline-none resize-none"
              />
            </div>
          </div>

          <div className="space-y-2 relative">
            <div className="flex justify-between items-center">
              <label className="text-xs text-zinc-500 uppercase font-bold tracking-widest mb-1 block">Descrição Narrativa</label>
              <button 
                onClick={handleGenerateDescription}
                disabled={isGenerating}
                className="flex items-center gap-2 text-xs text-yellow-500 hover:text-yellow-400 font-bold uppercase disabled:opacity-50"
              >
                {isGenerating ? 'Invocando...' : <><Sparkles size={14} /> Sugerir via Outro Lado</>}
              </button>
            </div>
            <textarea 
              rows={5}
              value={formData.descricao}
              onChange={e => setFormData({...formData, descricao: e.target.value})}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-4 text-zinc-300 text-sm focus:border-red-600 outline-none resize-none italic"
              placeholder="Descreva a forma horrenda desta entidade..."
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreatureForm;
