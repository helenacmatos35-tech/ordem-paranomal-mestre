
import React, { useState } from 'react';
import { Elemento, Ritual } from '../types';
import { Sparkles, Save, Flame } from 'lucide-react';
import { sugerirEfeitoRitual } from '../geminiService';

interface RitualFormProps {
  onSave: (ritual: Ritual) => void;
  initialData?: Ritual;
}

const RitualForm: React.FC<RitualFormProps> = ({ onSave, initialData }) => {
  const [formData, setFormData] = useState<Ritual>(initialData || {
    id: Math.random().toString(36).substr(2, 9),
    nome: '',
    elemento: Elemento.CONHECIMENTO,
    circulo: 1,
    custoSanidade: 1,
    execucao: 'Padrão',
    alcance: 'Curto',
    duracao: 'Instantânea',
    alvo: '1 ser',
    efeito: ''
  });

  const [isGenerating, setIsGenerating] = useState(false);

  const handleAISuggestion = async () => {
    if (!formData.nome) return alert('Dê um nome ao ritual!');
    setIsGenerating(true);
    const result = await sugerirEfeitoRitual(formData.nome, formData.elemento);
    setFormData({ ...formData, efeito: result || '' });
    setIsGenerating(false);
  };

  return (
    <div className="bg-zinc-900/90 border border-purple-900/30 rounded-xl overflow-hidden">
      <div className="bg-purple-950/20 p-6 border-b border-purple-900/20 flex justify-between items-center">
        <h3 className="font-cinzel text-2xl text-purple-500 font-bold flex items-center gap-3">
          <Flame className="text-purple-600" /> Transcender: Ritual
        </h3>
        <button onClick={() => onSave(formData)} className="bg-purple-700 hover:bg-purple-600 text-white px-6 py-2 rounded-lg font-bold flex items-center gap-2">
          <Save size={18} /> Aprender Ritual
        </button>
      </div>

      <div className="p-8 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2">
            <label className="text-xs text-zinc-500 uppercase font-bold mb-1 block">Nome do Ritual</label>
            <input value={formData.nome} onChange={e => setFormData({...formData, nome: e.target.value})} className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-zinc-100 focus:border-purple-600 outline-none" placeholder="Ex: Eco Doloroso" />
          </div>
          <div>
            <label className="text-xs text-zinc-500 uppercase font-bold mb-1 block">Círculo</label>
            <select value={formData.circulo} onChange={e => setFormData({...formData, circulo: parseInt(e.target.value) as any})} className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-zinc-100 outline-none">
              <option value={1}>1º Círculo</option>
              <option value={2}>2º Círculo</option>
              <option value={3}>3º Círculo</option>
              <option value={4}>4º Círculo</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div>
            <label className="text-xs text-zinc-500 uppercase font-bold mb-1 block">Elemento</label>
            <select value={formData.elemento} onChange={e => setFormData({...formData, elemento: e.target.value as Elemento})} className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-2 text-zinc-100 outline-none">
              {Object.values(Elemento).map(el => <option key={el} value={el}>{el}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs text-zinc-500 uppercase font-bold mb-1 block">Custo (SAN)</label>
            <input type="number" value={formData.custoSanidade} onChange={e => setFormData({...formData, custoSanidade: parseInt(e.target.value) || 0})} className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-2 text-zinc-100 outline-none" />
          </div>
          <div>
            <label className="text-xs text-zinc-500 uppercase font-bold mb-1 block">Execução</label>
            <input value={formData.execucao} onChange={e => setFormData({...formData, execucao: e.target.value})} className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-2 text-zinc-100 outline-none" />
          </div>
          <div>
            <label className="text-xs text-zinc-500 uppercase font-bold mb-1 block">Duração</label>
            <input value={formData.duracao} onChange={e => setFormData({...formData, duracao: e.target.value})} className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-2 text-zinc-100 outline-none" />
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex justify-between">
            <label className="text-xs text-zinc-500 uppercase font-bold">Efeito & Descrição</label>
            <button onClick={handleAISuggestion} disabled={isGenerating} className="text-xs text-purple-400 flex items-center gap-1 hover:text-purple-300">
              <Sparkles size={12} /> {isGenerating ? 'Canalizando...' : 'Sussurros do Outro Lado'}
            </button>
          </div>
          <textarea rows={6} value={formData.efeito} onChange={e => setFormData({...formData, efeito: e.target.value})} className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-4 text-zinc-300 text-sm focus:border-purple-600 outline-none resize-none italic" placeholder="O que acontece quando as palavras são proferidas?..." />
        </div>
      </div>
    </div>
  );
};

export default RitualForm;
