
import React, { useState, useEffect } from 'react';
import { Missao, Cena } from '../types';
import { MapPin, Plus, List, Trash2, ChevronRight, Layout, BookOpen } from 'lucide-react';

const MissionManager: React.FC = () => {
  const [missions, setMissions] = useState<Missao[]>([]);
  const [selectedMission, setSelectedMission] = useState<Missao | null>(null);
  const [isCreating, setIsCreating] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('paranormal_missions');
    if (saved) setMissions(JSON.parse(saved));
  }, []);

  useEffect(() => {
    localStorage.setItem('paranormal_missions', JSON.stringify(missions));
  }, [missions]);

  const addMission = () => {
    const newM: Missao = {
      id: Math.random().toString(36).substr(2, 9),
      titulo: 'Nova Missão',
      resumo: '',
      cenas: [],
      localizacao: 'Local Desconhecido'
    };
    setMissions([...missions, newM]);
    setSelectedMission(newM);
  };

  const addScene = (mId: string) => {
    setMissions(prev => prev.map(m => {
      if (m.id === mId) {
        const newScene: Cena = {
          id: Math.random().toString(36).substr(2, 9),
          titulo: `Cena ${m.cenas.length + 1}`,
          descricao: '',
          ameaca: '',
          objetivo: '',
          pistasIds: []
        };
        const updated = { ...m, cenas: [...m.cenas, newScene] };
        setSelectedMission(updated);
        return updated;
      }
      return m;
    }));
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
      {/* Sidebar de Missões */}
      <div className="lg:col-span-1 space-y-4">
        <button onClick={addMission} className="w-full bg-red-700 hover:bg-red-600 text-white p-4 rounded-xl font-bold flex items-center justify-center gap-2 shadow-lg">
          <Plus size={20} /> Nova Operação
        </button>
        <div className="space-y-2 max-h-[600px] overflow-y-auto paranormal-scroll pr-2">
          {missions.map(m => (
            <div 
              key={m.id} 
              onClick={() => setSelectedMission(m)}
              className={`p-4 rounded-xl border cursor-pointer transition-all ${selectedMission?.id === m.id ? 'bg-red-900/20 border-red-700/50' : 'bg-zinc-900 border-zinc-800 hover:border-zinc-700'}`}
            >
              <h4 className="font-cinzel font-bold text-zinc-100 truncate">{m.titulo}</h4>
              <p className="text-[10px] text-zinc-500 flex items-center gap-1 mt-1"><MapPin size={10} /> {m.localizacao}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Editor de Missão */}
      <div className="lg:col-span-3">
        {selectedMission ? (
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-8 space-y-8 animate-fadeIn">
            <div className="flex justify-between items-start">
              <div className="flex-1">
                <input 
                  value={selectedMission.titulo}
                  onChange={e => {
                    const val = e.target.value;
                    setMissions(prev => prev.map(m => m.id === selectedMission.id ? { ...m, titulo: val } : m));
                    setSelectedMission({ ...selectedMission, titulo: val });
                  }}
                  className="bg-transparent text-3xl font-cinzel font-bold text-white outline-none w-full border-b border-transparent focus:border-red-900 mb-2"
                />
                <input 
                  value={selectedMission.localizacao}
                  onChange={e => {
                    const val = e.target.value;
                    setMissions(prev => prev.map(m => m.id === selectedMission.id ? { ...m, localizacao: val } : m));
                    setSelectedMission({ ...selectedMission, localizacao: val });
                  }}
                  className="bg-transparent text-sm text-zinc-500 outline-none w-full"
                />
              </div>
              <button 
                onClick={() => {
                  setMissions(missions.filter(m => m.id !== selectedMission.id));
                  setSelectedMission(null);
                }}
                className="text-zinc-600 hover:text-red-500 p-2"
              >
                <Trash2 size={20} />
              </button>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-zinc-600 uppercase tracking-widest">Resumo da Missão</label>
              <textarea 
                value={selectedMission.resumo}
                onChange={e => {
                  const val = e.target.value;
                  setMissions(prev => prev.map(m => m.id === selectedMission.id ? { ...m, resumo: val } : m));
                  setSelectedMission({ ...selectedMission, resumo: val });
                }}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-4 text-zinc-300 text-sm outline-none h-24 resize-none focus:border-red-900"
                placeholder="Qual o objetivo principal desta operação?"
              />
            </div>

            <div className="space-y-4">
              <div className="flex justify-between items-center border-b border-zinc-800 pb-2">
                <h5 className="font-cinzel text-zinc-400 font-bold flex items-center gap-2"><Layout size={18} /> Fluxo de Cenas</h5>
                <button onClick={() => addScene(selectedMission.id)} className="text-xs text-red-500 hover:text-red-400 font-bold uppercase tracking-wider">+ Add Cena</button>
              </div>
              
              <div className="space-y-4">
                {selectedMission.cenas.map((cena, sIdx) => (
                  <div key={cena.id} className="bg-black/30 border border-zinc-800 rounded-xl p-6 group">
                    <div className="flex items-center gap-4 mb-4">
                      <div className="w-8 h-8 rounded-full bg-red-900/40 text-red-500 flex items-center justify-center font-bold text-xs">{sIdx + 1}</div>
                      <input 
                        value={cena.titulo}
                        onChange={e => {
                          const val = e.target.value;
                          const updatedCenas = selectedMission.cenas.map(c => c.id === cena.id ? { ...c, titulo: val } : c);
                          const updatedM = { ...selectedMission, cenas: updatedCenas };
                          setMissions(prev => prev.map(m => m.id === selectedMission.id ? updatedM : m));
                          setSelectedMission(updatedM);
                        }}
                        className="bg-transparent font-bold text-zinc-100 outline-none flex-1"
                      />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <textarea 
                        placeholder="O que acontece nesta cena?"
                        value={cena.descricao}
                        onChange={e => {
                          const val = e.target.value;
                          const updatedCenas = selectedMission.cenas.map(c => c.id === cena.id ? { ...c, descricao: val } : c);
                          const updatedM = { ...selectedMission, cenas: updatedCenas };
                          setMissions(prev => prev.map(m => m.id === selectedMission.id ? updatedM : m));
                          setSelectedMission(updatedM);
                        }}
                        className="bg-zinc-950/50 border border-zinc-800 rounded p-3 text-xs text-zinc-400 h-24 outline-none focus:border-red-900"
                      />
                      <div className="space-y-2">
                         <input 
                          placeholder="Objetivo da cena"
                          value={cena.objetivo}
                          onChange={e => {
                            const val = e.target.value;
                            const updatedCenas = selectedMission.cenas.map(c => c.id === cena.id ? { ...c, objetivo: val } : c);
                            const updatedM = { ...selectedMission, cenas: updatedCenas };
                            setMissions(prev => prev.map(m => m.id === selectedMission.id ? updatedM : m));
                            setSelectedMission(updatedM);
                          }}
                          className="w-full bg-zinc-950/50 border border-zinc-800 rounded p-2 text-xs text-zinc-400 outline-none focus:border-red-900"
                        />
                         <input 
                          placeholder="Ameaças presentes"
                          value={cena.ameaca}
                          onChange={e => {
                            const val = e.target.value;
                            const updatedCenas = selectedMission.cenas.map(c => c.id === cena.id ? { ...c, ameaca: val } : c);
                            const updatedM = { ...selectedMission, cenas: updatedCenas };
                            setMissions(prev => prev.map(m => m.id === selectedMission.id ? updatedM : m));
                            setSelectedMission(updatedM);
                          }}
                          className="w-full bg-zinc-950/50 border border-zinc-800 rounded p-2 text-xs text-zinc-400 outline-none focus:border-red-900"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <div className="h-full flex flex-col items-center justify-center border-2 border-dashed border-zinc-800 rounded-2xl opacity-30 py-40">
            <BookOpen size={64} className="mb-4" />
            <p className="font-cinzel text-xl">Selecione uma missão para detalhar o roteiro</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default MissionManager;
