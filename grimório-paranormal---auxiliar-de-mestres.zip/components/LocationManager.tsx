
import React, { useState, useEffect } from 'react';
import { Localidade, EstadoMembrana } from '../types';
import { Map, Plus, Trash2, Shield, AlertTriangle, Zap, Ghost } from 'lucide-react';

const LocationManager: React.FC = () => {
  const [locations, setLocations] = useState<Localidade[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);

  useEffect(() => {
    const saved = localStorage.getItem('paranormal_locations');
    if (saved) setLocations(JSON.parse(saved));
  }, []);

  useEffect(() => {
    localStorage.setItem('paranormal_locations', JSON.stringify(locations));
  }, [locations]);

  const addLocation = () => {
    const newL: Localidade = {
      id: Math.random().toString(36).substr(2, 9),
      nome: 'Nova Localidade',
      descricao: '',
      estadoMembrana: EstadoMembrana.ESTAVEL,
      pistasIds: [],
      perigos: ''
    };
    setLocations([...locations, newL]);
    setSelectedId(newL.id);
  };

  const updateLocation = (id: string, updates: Partial<Localidade>) => {
    setLocations(prev => prev.map(l => l.id === id ? { ...l, ...updates } : l));
  };

  const removeLocation = (id: string) => {
    if (confirm('Destruir registro desta localidade?')) {
      setLocations(locations.filter(l => l.id !== id));
      setSelectedId(null);
    }
  };

  const activeLoc = locations.find(l => l.id === selectedId);

  const membraneColors = {
    [EstadoMembrana.ESTAVEL]: 'text-green-500 border-green-900/30',
    [EstadoMembrana.FINA]: 'text-yellow-500 border-yellow-900/30',
    [EstadoMembrana.DANIFICADA]: 'text-orange-500 border-orange-900/30',
    [EstadoMembrana.ROMPIDA]: 'text-red-500 border-red-900/30 animate-pulse'
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
      <div className="lg:col-span-1 space-y-4">
        <button onClick={addLocation} className="w-full bg-blue-900/40 hover:bg-blue-800/60 text-blue-400 p-4 rounded-xl font-bold flex items-center justify-center gap-2 border border-blue-900/30 transition-all">
          <Plus size={20} /> Mapear Local
        </button>
        <div className="space-y-2 overflow-y-auto max-h-[600px] paranormal-scroll pr-2">
          {locations.map(l => (
            <div 
              key={l.id} 
              onClick={() => setSelectedId(l.id)}
              className={`p-4 rounded-xl border cursor-pointer transition-all ${selectedId === l.id ? 'bg-blue-900/20 border-blue-700/50' : 'bg-zinc-900 border-zinc-800 hover:border-zinc-700'}`}
            >
              <div className="flex justify-between items-start">
                <h4 className="font-cinzel font-bold text-zinc-100 truncate flex-1">{l.nome}</h4>
                <div className={`w-2 h-2 rounded-full mt-1.5 ${l.estadoMembrana === EstadoMembrana.ESTAVEL ? 'bg-green-500' : l.estadoMembrana === EstadoMembrana.ROMPIDA ? 'bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.8)]' : 'bg-yellow-500'}`} />
              </div>
              <p className="text-[10px] text-zinc-500 uppercase font-bold mt-1">{l.estadoMembrana}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="lg:col-span-3">
        {activeLoc ? (
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-8 space-y-8 animate-fadeIn">
            <div className="flex justify-between items-start">
              <input 
                value={activeLoc.nome}
                onChange={e => updateLocation(activeLoc.id, { nome: e.target.value })}
                className="bg-transparent text-3xl font-cinzel font-bold text-white outline-none w-full focus:border-b border-blue-900 mb-4"
              />
              <button onClick={() => removeLocation(activeLoc.id)} className="text-zinc-600 hover:text-red-500"><Trash2 size={20} /></button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-4">
                <label className="text-xs font-bold text-zinc-500 uppercase tracking-widest flex items-center gap-2">
                  <Shield size={14} /> Integridade da Membrana
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {Object.values(EstadoMembrana).map(estado => (
                    <button 
                      key={estado}
                      onClick={() => updateLocation(activeLoc.id, { estadoMembrana: estado })}
                      className={`p-3 rounded-lg border text-[10px] font-bold uppercase transition-all ${activeLoc.estadoMembrana === estado ? membraneColors[estado] + ' bg-zinc-800' : 'bg-zinc-950 border-zinc-800 text-zinc-600 hover:border-zinc-700'}`}
                    >
                      {estado}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-4">
                <label className="text-xs font-bold text-zinc-500 uppercase tracking-widest flex items-center gap-2">
                  <AlertTriangle size={14} className="text-yellow-500" /> Perigos & Entidades
                </label>
                <textarea 
                  value={activeLoc.perigos}
                  onChange={e => updateLocation(activeLoc.id, { perigos: e.target.value })}
                  placeholder="Quais perigos espreitam aqui?"
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-4 text-zinc-300 text-sm h-28 outline-none focus:border-blue-900 resize-none"
                />
              </div>
            </div>

            <div className="space-y-4">
              <label className="text-xs font-bold text-zinc-500 uppercase tracking-widest flex items-center gap-2">
                <Map size={14} className="text-blue-500" /> Descrição do Ambiente
              </label>
              <textarea 
                value={activeLoc.descricao}
                onChange={e => updateLocation(activeLoc.id, { descricao: e.target.value })}
                placeholder="Como é este lugar? Sons, cheiros, iluminação..."
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-4 text-zinc-300 text-sm h-40 outline-none focus:border-blue-900 resize-none font-serif italic"
              />
            </div>
          </div>
        ) : (
          <div className="h-full flex flex-col items-center justify-center border-2 border-dashed border-zinc-800 rounded-2xl opacity-30 py-40">
            <Map size={64} className="mb-4" />
            <p className="font-cinzel text-xl">Nenhum local selecionado no radar</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default LocationManager;
