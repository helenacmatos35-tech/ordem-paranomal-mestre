
import React, { useState, useEffect } from 'react';
// Added Plus to the lucide-react imports to fix the "Cannot find name 'Plus'" error
import { Sparkles, Search, Eye, ListCheck, Clock, AlertCircle, Calculator, ShieldAlert, Brain, Wand2, Users, Plus } from 'lucide-react';
import { sugerirMisterio, gerarReviravolta } from '../geminiService';
import { Pista, Elemento } from '../types';

const DMScreen: React.FC = () => {
  const [mystery, setMystery] = useState('');
  const [twist, setTwist] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [notes, setNotes] = useState('');
  const [pistas, setPistas] = useState<Pista[]>([]);
  const [novaPista, setNovaPista] = useState('');
  
  // Player Stats tracking
  const [players, setPlayers] = useState(() => {
    const saved = localStorage.getItem('party_stats');
    return saved ? JSON.parse(saved) : [
      { id: '1', nome: 'Jogador 1', nex: 15, sanidade: 30, maxSan: 30 },
      { id: '2', nome: 'Jogador 2', nex: 15, sanidade: 30, maxSan: 30 },
    ];
  });

  useEffect(() => {
    localStorage.setItem('party_stats', JSON.stringify(players));
  }, [players]);

  const updateSan = (id: string, delta: number) => {
    setPlayers(players.map(p => p.id === id ? { ...p, sanidade: Math.max(0, Math.min(p.maxSan, p.sanidade + delta)) } : p));
  };

  const [nex, setNex] = useState(5);
  const [dtComplexity, setDtComplexity] = useState(1);

  const calculateDT = () => {
    const base = 10 + Math.floor(nex / 5) * 5;
    if (dtComplexity === 1) return base;
    if (dtComplexity === 2) return base + 5;
    return base + 10;
  };

  const generateMystery = async () => {
    setIsLoading(true);
    const result = await sugerirMisterio();
    setMystery(result || '');
    setIsLoading(false);
  };

  const handleTwist = async () => {
    setIsLoading(true);
    const result = await gerarReviravolta(Elemento.MEDO, mystery || "Investigação paranormal genérica");
    setTwist(result || '');
    setIsLoading(false);
  };

  const addPista = () => {
    if (!novaPista) return;
    setPistas([...pistas, { id: Date.now().toString(), titulo: novaPista, descricao: '', encontrada: false }]);
    setNovaPista('');
  };

  return (
    <div className="space-y-8">
      {/* Grupo Status Row */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 shadow-xl">
        <h3 className="font-cinzel text-xl text-zinc-100 mb-4 flex items-center gap-3">
          <Users size={20} className="text-blue-500" /> Status da Equipe
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {players.map(p => (
            <div key={p.id} className="bg-black/40 border border-zinc-800 rounded-xl p-4 flex flex-col gap-2">
              <div className="flex justify-between items-center">
                <span className="font-bold text-xs text-zinc-400">{p.nome} (NEX {p.nex}%)</span>
                <span className="text-[10px] text-blue-500 font-bold uppercase">Sanidade</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex-1 bg-zinc-950 h-2 rounded-full overflow-hidden border border-zinc-800">
                  <div 
                    className="h-full bg-blue-600 transition-all duration-500"
                    style={{ width: `${(p.sanidade / p.maxSan) * 100}%` }}
                  />
                </div>
                <div className="flex gap-1">
                  <button onClick={() => updateSan(p.id, -1)} className="text-red-500 hover:bg-zinc-800 px-1 rounded">-</button>
                  <span className="text-xs font-bold text-white w-6 text-center">{p.sanidade}</span>
                  <button onClick={() => updateSan(p.id, 1)} className="text-green-500 hover:bg-zinc-800 px-1 rounded">+</button>
                </div>
              </div>
            </div>
          ))}
          <button onClick={() => setPlayers([...players, { id: Date.now().toString(), nome: 'Novo Agente', nex: 5, sanidade: 20, maxSan: 20 }])} className="border-2 border-dashed border-zinc-800 rounded-xl flex items-center justify-center text-zinc-600 hover:text-white transition-colors">
            <Plus size={24} />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-zinc-900/80 border border-zinc-800 rounded-xl p-6 shadow-xl relative overflow-hidden">
            <div className="flex justify-between items-center border-b border-zinc-800 pb-4 mb-4">
              <h3 className="font-cinzel text-xl text-yellow-500 flex items-center gap-3">
                <Search className="text-yellow-600" /> Investigação Ativa
              </h3>
              <div className="flex gap-2">
                <button onClick={handleTwist} disabled={isLoading} className="bg-purple-900/20 hover:bg-purple-700/40 text-purple-500 px-4 py-1 rounded-full text-xs font-bold transition-colors flex items-center gap-2">
                  <Wand2 size={12} /> Plot Twist
                </button>
                <button onClick={generateMystery} disabled={isLoading} className="bg-yellow-700/20 hover:bg-yellow-700/40 text-yellow-500 px-4 py-1 rounded-full text-xs font-bold transition-colors">
                  {isLoading ? 'Invocando...' : 'Novo Mistério'}
                </button>
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="min-h-[150px] text-base text-zinc-300 whitespace-pre-wrap font-serif italic bg-black/20 p-4 rounded-lg border border-zinc-800/50 leading-relaxed">
                {mystery || "O Outro Lado aguarda suas perguntas..."}
              </div>
              
              {twist && (
                <div className="bg-purple-900/10 border border-purple-900/30 p-4 rounded-lg animate-fadeIn">
                   <h5 className="text-[10px] text-purple-500 font-bold uppercase mb-2 tracking-widest flex items-center gap-2">
                     <AlertCircle size={10} /> Reviravolta Inesperada
                   </h5>
                   <p className="text-sm text-zinc-300 italic">{twist}</p>
                </div>
              )}
            </div>
          </div>

          <div className="bg-zinc-900/80 border border-zinc-800 rounded-xl p-6">
            <h3 className="font-cinzel text-xl text-blue-500 mb-4 flex items-center gap-3">
              <ListCheck size={20} /> Quadro de Pistas
            </h3>
            <div className="flex gap-2 mb-4">
              <input value={novaPista} onChange={e => setNovaPista(e.target.value)} placeholder="Nova pista descoberta..." className="flex-1 bg-zinc-950 border border-zinc-800 rounded p-3 text-sm text-white outline-none focus:border-blue-600" />
              <button onClick={addPista} className="bg-blue-700 hover:bg-blue-600 px-6 py-2 rounded font-bold text-sm transition-colors">Add</button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 max-h-60 overflow-y-auto paranormal-scroll pr-2">
              {pistas.map(p => (
                <div key={p.id} onClick={() => setPistas(pistas.map(it => it.id === p.id ? {...it, encontrada: !it.encontrada} : it))} className={`p-4 rounded-xl border cursor-pointer transition-all flex items-center justify-between ${p.encontrada ? 'bg-blue-900/20 border-blue-900/50 text-blue-400 opacity-80' : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:border-blue-600'}`}>
                  <span className={p.encontrada ? 'line-through' : ''}>{p.titulo}</span>
                  {p.encontrada ? <Eye size={14} /> : <AlertCircle size={14} className="opacity-20" />}
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-zinc-900 border border-red-900/20 rounded-xl p-6 h-[300px] flex flex-col shadow-xl">
            <h3 className="font-cinzel text-xl text-red-500 mb-4 flex items-center gap-3">
              <Clock size={20} /> Notas Rápidas
            </h3>
            <textarea value={notes} onChange={e => setNotes(e.target.value)} placeholder="Anotações da sessão..." className="flex-1 bg-black/40 border border-zinc-800 rounded-lg p-4 text-zinc-300 text-sm outline-none resize-none paranormal-scroll" />
          </div>

          <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6 shadow-xl">
            <h3 className="font-cinzel text-xl text-purple-500 mb-4 flex items-center gap-3">
              <Calculator size={20} /> Calculadora de DT
            </h3>
            <div className="space-y-4">
               <div>
                  <label className="text-[10px] text-zinc-500 uppercase font-bold mb-1 block">NEX Médio</label>
                  <input type="number" step="5" value={nex} onChange={e => setNex(parseInt(e.target.value) || 0)} className="w-full bg-zinc-950 border border-zinc-800 rounded p-2 text-white" />
               </div>
               <div>
                  <select value={dtComplexity} onChange={e => setDtComplexity(parseInt(e.target.value))} className="w-full bg-zinc-950 border border-zinc-800 rounded p-2 text-white outline-none">
                    <option value={1}>Fácil (Base)</option>
                    <option value={2}>Média (Base + 5)</option>
                    <option value={3}>Difícil (Base + 10)</option>
                  </select>
               </div>
               <div className="bg-black/40 p-4 rounded-xl border border-purple-900/30 text-center">
                  <span className="text-4xl font-bold text-white">{calculateDT()}</span>
               </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DMScreen;
