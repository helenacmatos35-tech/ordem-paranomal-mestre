
import React, { useState } from 'react';
import { NPC } from '../types';
import { Save, UserCircle, Sparkles, Ghost } from 'lucide-react';
import { gerarSegredoNPC } from '../geminiService';

interface NPCFormProps {
  onSave: (npc: NPC) => void;
  initialData?: NPC;
}

const NPCForm: React.FC<NPCFormProps> = ({ onSave, initialData }) => {
  const [formData, setFormData] = useState<NPC>(initialData || {
    id: Math.random().toString(36).substr(2, 9),
    nome: '',
    funcao: '',
    personalidade: '',
    medos: '',
    segredos: '',
    atributos: {},
    pericias: '',
    corrupcao: 'Nenhuma'
  });

  const [isGenerating, setIsGenerating] = useState(false);

  const handleGenerateSecret = async () => {
    if (!formData.nome || !formData.funcao) return alert('Dê um nome e função ao NPC!');
    setIsGenerating(true);
    const secret = await gerarSegredoNPC(formData.nome, formData.funcao);
    setFormData({...formData, segredos: secret || ''});
    setIsGenerating(false);
  };

  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden shadow-2xl">
      <div className="bg-zinc-800/50 p-6 border-b border-zinc-800 flex justify-between items-center">
        <h3 className="font-cinzel text-2xl text-zinc-300 font-bold flex items-center gap-3">
          <UserCircle className="text-zinc-500" /> Registro de Civil
        </h3>
        <button onClick={() => onSave(formData)} className="bg-zinc-700 hover:bg-zinc-600 text-white px-6 py-2 rounded-lg font-bold flex items-center gap-2">
          <Save size={18} /> Arquivar NPC
        </button>
      </div>

      <div className="p-8 grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-4">
          <div>
            <label className="text-xs text-zinc-500 uppercase font-bold mb-1 block">Nome Completo</label>
            <input value={formData.nome} onChange={e => setFormData({...formData, nome: e.target.value})} className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-zinc-100 outline-none focus:border-blue-600" />
          </div>
          <div>
            <label className="text-xs text-zinc-500 uppercase font-bold mb-1 block">Função Narrativa</label>
            <input value={formData.funcao} onChange={e => setFormData({...formData, funcao: e.target.value})} placeholder="Ex: Bibliotecária, Sobrevivente..." className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-zinc-100 outline-none focus:border-blue-600" />
          </div>
          <div>
            <label className="text-xs text-zinc-500 uppercase font-bold mb-1 block">Personalidade</label>
            <textarea value={formData.personalidade} onChange={e => setFormData({...formData, personalidade: e.target.value})} className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-zinc-100 outline-none resize-none h-24" />
          </div>
        </div>

        <div className="space-y-4">
          <div className="bg-black/40 p-4 rounded-lg border border-zinc-800 space-y-4">
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="text-xs text-red-500 uppercase font-bold">Segredos & Traumas</label>
                <button onClick={handleGenerateSecret} disabled={isGenerating} className="text-[10px] text-zinc-500 hover:text-white flex items-center gap-1">
                   <Sparkles size={10} /> {isGenerating ? 'Revelando...' : 'Revelar Segredo'}
                </button>
              </div>
              <textarea value={formData.segredos} onChange={e => setFormData({...formData, segredos: e.target.value})} className="w-full bg-zinc-900 border border-zinc-800 rounded p-2 text-xs text-zinc-300 outline-none h-20" />
            </div>
            <div>
              <label className="text-xs text-purple-500 uppercase font-bold mb-1 block flex items-center gap-1"><Ghost size={12}/> Corrupção Paranormal</label>
              <input value={formData.corrupcao} onChange={e => setFormData({...formData, corrupcao: e.target.value})} className="w-full bg-zinc-900 border border-zinc-800 rounded p-2 text-xs text-zinc-300 outline-none" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NPCForm;
