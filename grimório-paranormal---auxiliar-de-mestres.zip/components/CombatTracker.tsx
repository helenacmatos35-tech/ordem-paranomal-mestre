
import React, { useState } from 'react';
import { Sword, Plus, Trash2, Heart, User, ShieldCheck } from 'lucide-react';
import { ParticipanteCombate } from '../types';

const CombatTracker: React.FC = () => {
  const [participants, setParticipants] = useState<ParticipanteCombate[]>([]);
  const [newName, setNewName] = useState('');
  const [newInit, setNewInit] = useState(10);
  const [newHP, setNewHP] = useState(20);
  const [isPlayer, setIsPlayer] = useState(true);

  const addParticipant = () => {
    if (!newName) return;
    const newP: ParticipanteCombate = {
      id: Math.random().toString(36).substr(2, 9),
      nome: newName,
      iniciativa: newInit,
      vidaAtual: newHP,
      vidaMaxima: newHP,
      isPlayer: isPlayer,
      condicoes: []
    };
    setParticipants([...participants, newP].sort((a, b) => b.iniciativa - a.iniciativa));
    setNewName('');
  };

  const updateHP = (id: string, delta: number) => {
    setParticipants(participants.map(p => 
      p.id === id ? { ...p, vidaAtual: Math.max(0, p.vidaAtual + delta) } : p
    ));
  };

  const removeParticipant = (id: string) => {
    setParticipants(participants.filter(p => p.id !== id));
  };

  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-8 shadow-2xl">
      <h3 className="font-cinzel text-2xl text-red-500 font-bold mb-6 flex items-center gap-3">
        <Sword className="animate-pulse" /> Gerenciador de Combate
      </h3>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8 bg-black/40 p-6 rounded-xl border border-zinc-800">
        <div className="md:col-span-2">
          <label className="text-[10px] uppercase font-bold text-zinc-500 block mb-1">Nome</label>
          <input value={newName} onChange={e => setNewName(e.target.value)} className="w-full bg-zinc-950 border border-zinc-800 rounded p-2 text-white outline-none focus:border-red-600" />
        </div>
        <div>
          <label className="text-[10px] uppercase font-bold text-zinc-500 block mb-1">Iniciativa</label>
          <input type="number" value={newInit} onChange={e => setNewInit(parseInt(e.target.value) || 0)} className="w-full bg-zinc-950 border border-zinc-800 rounded p-2 text-white outline-none" />
        </div>
        <div>
          <label className="text-[10px] uppercase font-bold text-zinc-500 block mb-1">Vida Max</label>
          <input type="number" value={newHP} onChange={e => setNewHP(parseInt(e.target.value) || 0)} className="w-full bg-zinc-950 border border-zinc-800 rounded p-2 text-white outline-none" />
        </div>
        <div className="md:col-span-4 flex justify-between items-center mt-2">
          <label className="flex items-center gap-2 cursor-pointer">
            <input type="checkbox" checked={isPlayer} onChange={e => setIsPlayer(e.target.checked)} className="accent-red-600" />
            <span className="text-xs text-zinc-400">É Jogador?</span>
          </label>
          <button onClick={addParticipant} className="bg-red-700 hover:bg-red-600 text-white px-8 py-2 rounded-lg font-bold flex items-center gap-2">
            <Plus size={18} /> Entrar na Luta
          </button>
        </div>
      </div>

      <div className="space-y-3">
        {participants.map((p, idx) => (
          <div key={p.id} className={`flex items-center gap-4 p-4 rounded-xl border transition-all ${p.isPlayer ? 'bg-zinc-800/20 border-zinc-700' : 'bg-red-950/5 border-red-900/30'}`}>
            <div className="w-12 h-12 flex flex-col items-center justify-center bg-black/40 rounded-lg border border-zinc-700">
              <span className="text-[10px] text-zinc-500 uppercase font-bold">Pos</span>
              <span className="text-lg font-bold text-zinc-300">{idx + 1}</span>
            </div>
            
            <div className="w-16 h-12 flex flex-col items-center justify-center bg-red-900/20 rounded-lg border border-red-700/30">
              <span className="text-[10px] text-red-500 uppercase font-bold font-cinzel">Init</span>
              <span className="text-lg font-bold text-red-500">{p.iniciativa}</span>
            </div>

            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                {p.isPlayer ? <User size={14} className="text-blue-500" /> : <Sword size={14} className="text-red-600" />}
                <h4 className="font-cinzel font-bold text-zinc-100">{p.nome}</h4>
              </div>
              <div className="w-full bg-zinc-950 h-2 rounded-full overflow-hidden border border-zinc-800">
                <div 
                  className={`h-full transition-all ${p.vidaAtual / p.vidaMaxima > 0.5 ? 'bg-green-600' : p.vidaAtual / p.vidaMaxima > 0.2 ? 'bg-yellow-600' : 'bg-red-600'}`}
                  style={{ width: `${(p.vidaAtual / p.vidaMaxima) * 100}%` }}
                />
              </div>
            </div>

            <div className="flex items-center gap-3">
               <div className="flex items-center bg-black/40 rounded-lg border border-zinc-800 overflow-hidden">
                  <button onClick={() => updateHP(p.id, -1)} className="p-2 hover:bg-zinc-800 text-red-500">-</button>
                  <span className="px-4 font-bold text-zinc-100">{p.vidaAtual} <span className="text-[10px] text-zinc-600">/ {p.vidaMaxima}</span></span>
                  <button onClick={() => updateHP(p.id, 1)} className="p-2 hover:bg-zinc-800 text-green-500">+</button>
               </div>
               <button onClick={() => removeParticipant(p.id)} className="text-zinc-600 hover:text-red-500 p-2">
                 <Trash2 size={18} />
               </button>
            </div>
          </div>
        ))}
        {participants.length === 0 && (
          <div className="py-20 text-center text-zinc-600 italic">O silêncio precede o horror. Adicione participantes para começar.</div>
        )}
      </div>
    </div>
  );
};

export default CombatTracker;
