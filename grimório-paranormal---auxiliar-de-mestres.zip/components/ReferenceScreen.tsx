
import React from 'react';
import { Book, Star, Shield, Zap, Heart, Brain, Award } from 'lucide-react';

const ReferenceScreen: React.FC = () => {
  const nexData = [
    { nex: '5%', pv: '+2/3/4', san: '+2/3/5', pe: '+1', hab: 'Habilidade de Classe' },
    { nex: '10%', pv: '+2/3/4', san: '+2/3/5', pe: '+1', hab: 'Habilidade de Trilha' },
    { nex: '15%', pv: '+2/3/4', san: '+2/3/5', pe: '+1', hab: 'Poder de Classe' },
    { nex: '20%', pv: '+2/3/4', san: '+2/3/5', pe: '+1', hab: 'Aumento de Atributo' },
    { nex: '25%', pv: '+2/3/4', san: '+2/3/5', pe: '+1', hab: 'Habilidade de Classe' },
    { nex: '30%', pv: '+2/3/4', san: '+2/3/5', pe: '+1', hab: 'Poder de Classe' },
    { nex: '35%', pv: '+2/3/4', san: '+2/3/5', pe: '+1', hab: 'Grau de Treinamento' },
    { nex: '40%', pv: '+2/3/4', san: '+2/3/5', pe: '+1', hab: 'Habilidade de Trilha' },
    { nex: '45%', pv: '+2/3/4', san: '+2/3/5', pe: '+1', hab: 'Poder de Classe' },
    { nex: '50%', pv: '+2/3/4', san: '+2/3/5', pe: '+1', hab: 'Versatilidade / Atributo' },
  ];

  const patentData = [
    { nome: 'Recruta', nex: '0%', limite: '1', prestígio: '0' },
    { nome: 'Operador', nex: '20%', limite: '2', prestígio: '20' },
    { nome: 'Agente Especial', nex: '40%', limite: '3', prestígio: '50' },
    { nome: 'Oficial de Operações', nex: '65%', limite: '4', prestígio: '100' },
    { nome: 'Agente de Elite', nex: '85%', limite: '5', prestígio: '200' },
  ];

  return (
    <div className="space-y-12">
      {/* Seção NEX */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden shadow-2xl">
        <div className="bg-zinc-800/40 p-6 border-b border-zinc-800 flex items-center gap-3">
          <Award className="text-yellow-600" />
          <h3 className="font-cinzel text-xl text-zinc-100 font-bold">Progressão de NEX (Exposição Paranormal)</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-black/40 text-[10px] uppercase tracking-widest text-zinc-500 border-b border-zinc-800">
                <th className="p-4">NEX</th>
                <th className="p-4">PV (Comb/Esp/Ocul)</th>
                <th className="p-4">SAN (Comb/Esp/Ocul)</th>
                <th className="p-4">PE/Nível</th>
                <th className="p-4">Novas Habilidades</th>
              </tr>
            </thead>
            <tbody className="text-sm">
              {nexData.map((row, i) => (
                <tr key={i} className="border-b border-zinc-800/50 hover:bg-zinc-800/20 transition-colors">
                  <td className="p-4 font-bold text-red-500">{row.nex}</td>
                  <td className="p-4 text-zinc-300">{row.pv}</td>
                  <td className="p-4 text-zinc-300">{row.san}</td>
                  <td className="p-4 text-zinc-300">{row.pe}</td>
                  <td className="p-4 text-zinc-400 italic">{row.hab}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Patentes */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden">
          <div className="bg-blue-950/20 p-6 border-b border-zinc-800 flex items-center gap-3">
            <Shield className="text-blue-500" />
            <h3 className="font-cinzel text-lg text-zinc-100 font-bold">Hierarquia da Ordem (Patentes)</h3>
          </div>
          <div className="p-6 space-y-4">
            {patentData.map((p, i) => (
              <div key={i} className="flex items-center justify-between p-3 bg-black/20 rounded-lg border border-zinc-800">
                <div>
                  <h4 className="font-bold text-zinc-200">{p.nome}</h4>
                  <p className="text-[10px] text-zinc-500 uppercase tracking-tighter">Mínimo: {p.nex} NEX</p>
                </div>
                <div className="text-right">
                   <div className="text-xs font-bold text-blue-400">Limite Item: Cat {p.limite}</div>
                   <div className="text-[10px] text-zinc-600">Prestígio: {p.prestígio}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Resumo Regras Rápidas */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden">
          <div className="bg-red-950/20 p-6 border-b border-zinc-800 flex items-center gap-3">
            <Book className="text-red-500" />
            <h3 className="font-cinzel text-lg text-zinc-100 font-bold">Glossário de Combate</h3>
          </div>
          <div className="p-6 space-y-4">
             <div className="p-3 bg-zinc-950 rounded-lg border border-zinc-800">
               <b className="text-xs text-red-600 uppercase">Esquiva:</b>
               <p className="text-xs text-zinc-400 mt-1">Soma seus Reflexos na Defesa contra o próximo ataque.</p>
             </div>
             <div className="p-3 bg-zinc-950 rounded-lg border border-zinc-800">
               <b className="text-xs text-red-600 uppercase">Bloqueio:</b>
               <p className="text-xs text-zinc-400 mt-1">Soma sua Fortitude na Resistência a Dano (RD) do ataque.</p>
             </div>
             <div className="p-3 bg-zinc-950 rounded-lg border border-zinc-800">
               <b className="text-xs text-blue-600 uppercase">Contra-Ataque:</b>
               <p className="text-xs text-zinc-400 mt-1">Se vencer o teste de oposição de Luta, realiza um ataque imediato.</p>
             </div>
             <div className="p-3 bg-zinc-950 rounded-lg border border-zinc-800">
               <b className="text-xs text-yellow-600 uppercase">Interromper Ritual:</b>
               <p className="text-xs text-zinc-400 mt-1">Dano sofrido durante execução exige teste de Vontade (DT 10 + dano).</p>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReferenceScreen;
