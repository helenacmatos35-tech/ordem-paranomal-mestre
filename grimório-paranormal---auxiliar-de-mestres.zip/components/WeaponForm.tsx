
import React, { useState } from 'react';
import { Arma, TipoArma } from '../types';
import { Save, Swords, Crosshair, Box, Star } from 'lucide-react';

interface WeaponFormProps {
  onSave: (weapon: Arma) => void;
  initialData?: Arma;
}

const WeaponForm: React.FC<WeaponFormProps> = ({ onSave, initialData }) => {
  const [formData, setFormData] = useState<Arma>(initialData || {
    id: Math.random().toString(36).substr(2, 9),
    nome: '',
    tipo: TipoArma.BRANCA,
    dano: '1d6',
    critico: 'x2',
    alcance: 'Adjacente',
    espaco: 1,
    categoria: 0,
    descricao: ''
  });

  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden shadow-2xl">
      <div className="bg-zinc-800/50 p-6 border-b border-zinc-800 flex justify-between items-center">
        <h3 className="font-cinzel text-2xl text-zinc-300 font-bold flex items-center gap-3">
          {formData.tipo === TipoArma.BRANCA ? <Swords className="text-zinc-500" /> : <Crosshair className="text-zinc-500" />} 
          Arsenal da Ordem
        </h3>
        <button onClick={() => onSave(formData)} className="bg-red-700 hover:bg-red-600 text-white px-6 py-2 rounded-lg font-bold flex items-center gap-2 transition-all">
          <Save size={18} /> Salvar Arma
        </button>
      </div>

      <div className="p-8 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="text-xs text-zinc-500 uppercase font-bold mb-1 block">Nome da Arma</label>
            <input 
              value={formData.nome} 
              onChange={e => setFormData({...formData, nome: e.target.value})} 
              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-zinc-100 outline-none focus:border-red-600" 
              placeholder="Ex: Katana Amaldiçoada"
            />
          </div>
          <div>
            <label className="text-xs text-zinc-500 uppercase font-bold mb-1 block">Tipo de Arma</label>
            <select 
              value={formData.tipo} 
              onChange={e => setFormData({...formData, tipo: e.target.value as TipoArma})} 
              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-zinc-100 outline-none"
            >
              <option value={TipoArma.BRANCA}>Arma Branca</option>
              <option value={TipoArma.FOGO}>Arma de Fogo</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div>
            <label className="text-xs text-zinc-500 uppercase font-bold mb-1 block">Dano</label>
            <input 
              value={formData.dano} 
              onChange={e => setFormData({...formData, dano: e.target.value})} 
              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-2 text-zinc-100 outline-none" 
              placeholder="Ex: 2d8"
            />
          </div>
          <div>
            <label className="text-xs text-zinc-500 uppercase font-bold mb-1 block">Crítico</label>
            <input 
              value={formData.critico} 
              onChange={e => setFormData({...formData, critico: e.target.value})} 
              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-2 text-zinc-100 outline-none" 
              placeholder="Ex: 19/x3"
            />
          </div>
          <div>
            <label className="text-xs text-zinc-500 uppercase font-bold mb-1 block">Alcance</label>
            <input 
              value={formData.alcance} 
              onChange={e => setFormData({...formData, alcance: e.target.value})} 
              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-2 text-zinc-100 outline-none" 
              placeholder="Ex: Médio"
            />
          </div>
          <div>
            <label className="text-xs text-zinc-500 uppercase font-bold mb-1 block flex items-center gap-1"><Box size={10}/> Espaço</label>
            <input 
              type="number" 
              value={formData.espaco} 
              onChange={e => setFormData({...formData, espaco: parseInt(e.target.value) || 1})} 
              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-2 text-zinc-100 outline-none"
            />
          </div>
        </div>

        <div>
          <label className="text-xs text-zinc-500 uppercase font-bold mb-1 block flex items-center gap-1"><Star size={10}/> Categoria</label>
          <select 
            value={formData.categoria} 
            onChange={e => setFormData({...formData, categoria: parseInt(e.target.value)})} 
            className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-2 text-zinc-100 outline-none"
          >
             <option value={0}>Categoria 0 (Mundano)</option>
             <option value={1}>Categoria I</option>
             <option value={2}>Categoria II</option>
             <option value={3}>Categoria III</option>
             <option value={4}>Categoria IV</option>
          </select>
        </div>

        <div>
          <label className="text-xs text-zinc-500 uppercase font-bold mb-1 block">Descrição Narrativa</label>
          <textarea 
            rows={4} 
            value={formData.descricao} 
            onChange={e => setFormData({...formData, descricao: e.target.value})} 
            className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-4 text-zinc-300 text-sm focus:border-red-600 outline-none resize-none italic" 
            placeholder="Descreva a aparência, peso e história desta arma..."
          />
        </div>
      </div>
    </div>
  );
};

export default WeaponForm;
