
import { Ritual, Elemento, Criatura, NPC, Arma, TipoArma, Condicao, Classe, Vilao } from './types';

export const OFFICIAL_CONDITIONS: Condicao[] = [
  { nome: 'Agonizando', efeito: 'Você está prestes a morrer.', penalidade: 'Você fica caído e só pode realizar uma ação de movimento por turno. Se sofrer qualquer dano, morre.' },
  { nome: 'Alquebrado', efeito: 'Cansaço mental ou espiritual.', penalidade: 'O custo em PE de suas habilidades e rituais aumenta em +1.' },
  { nome: 'Abalado', efeito: 'Medo leve.', penalidade: '–2 em testes de perícia.' },
  { nome: 'Apavorado', efeito: 'Medo intenso.', penalidade: '–5 em testes de perícia e você deve fugir da fonte do medo.' },
  { nome: 'Cego', efeito: 'Privação de visão.', penalidade: '–5 em testes de perícia baseados em visão e em Defesa. Todos os alvos têm camuflagem total contra você.' },
  { nome: 'Confuso', efeito: 'Mente perturbada.', penalidade: 'Você deve rolar 1d6 no início do turno: 1-3 age normalmente, 4-5 fica parado, 6 ataca o ser mais próximo.' },
  { nome: 'Debilitado', efeito: 'Corpo seriamente ferido.', penalidade: '–5 em testes de perícia físicos (Força, Agilidade, Vigor).' },
  { nome: 'Emaranhado', efeito: 'Preso por algo.', penalidade: '–2 em testes de ataque e Agilidade, e sua velocidade é reduzida à metade.' },
  { nome: 'Enfeitiçado', efeito: 'Sob controle paranormal.', penalidade: 'Você não pode atacar o ser que te enfeitiçou e o trata como um aliado próximo.' },
  { nome: 'Fatigado', efeito: 'Exaustão física.', penalidade: '–2 em Defesa e testes de perícia físicos. Não pode correr ou realizar carga.' },
  { nome: 'Fraco', efeito: 'Desgaste leve.', penalidade: '–2 em testes de perícia físicos.' },
  { nome: 'Imobilizado', efeito: 'Totalmente contido.', penalidade: '–5 em Defesa e você não pode realizar ações, exceto tentar se libertar.' },
  { nome: 'Paralisado', efeito: 'Músculos travados.', penalidade: 'Sua Defesa é 10 e você não pode realizar nenhuma ação.' },
  { nome: 'Sangrando', efeito: 'Ferimento aberto.', penalidade: 'No início de cada turno, você perde 1d6 PV. Estancável com teste de Medicina (DT 15).' },
  { nome: 'Vulnerável', efeito: 'Exposto a ataques.', penalidade: '–2 na Defesa.' }
];

export const DEFAULT_RITUALS: Ritual[] = [
  // 🔴 SANGUE
  { id: 's1', nome: 'Arma de Sangue', elemento: Elemento.SANGUE, circulo: 1, custoSanidade: 1, execucao: 'Padrão', alcance: 'Pessoal', duracao: 'Cena', alvo: 'Você', efeito: 'Cria uma arma orgânica (1d6 dano de Sangue). Pode atacar como ação extra.' },
  { id: 's2', nome: 'Armadura de Sangue', elemento: Elemento.SANGUE, circulo: 1, custoSanidade: 1, execucao: 'Padrão', alcance: 'Pessoal', duracao: 'Cena', alvo: 'Você', efeito: 'Sua pele endurece, concedendo +5 de Defesa.' },
  { id: 's3', nome: 'Consumir Manancial', elemento: Elemento.SANGUE, circulo: 1, custoSanidade: 1, execucao: 'Padrão', alcance: 'Toque', duracao: 'Instantânea', alvo: '1 ser', efeito: 'Drena a vitalidade do alvo, causando 2d6 de dano de Sangue e você recebe PV temporários iguais ao dano.' },
  { id: 's4', nome: 'Fortalecer Sangue', elemento: Elemento.SANGUE, circulo: 1, custoSanidade: 1, execucao: 'Padrão', alcance: 'Toque', duracao: 'Cena', alvo: '1 ser', efeito: 'O alvo recebe +2 em testes de Força e Vigor.' },
  { id: 's5', nome: 'Ódio Incontrolável', elemento: Elemento.SANGUE, circulo: 1, custoSanidade: 1, execucao: 'Padrão', alcance: 'Curto', duracao: 'Cena', alvo: '1 ser', efeito: 'Alvo entra em fúria: +2 em testes de ataque e dano corpo a corpo, mas não pode realizar ações defensivas.' },
  { id: 's7', nome: 'Hemorragia', elemento: Elemento.SANGUE, circulo: 2, custoSanidade: 3, execucao: 'Padrão', alcance: 'Médio', duracao: 'Cena', alvo: '1 ser', efeito: 'O sangue do alvo ferve e sai pelos poros. Causa 4d6 de dano de Sangue por turno.' },
  { id: 's9', nome: 'Ascensão Bestial', elemento: Elemento.SANGUE, circulo: 3, custoSanidade: 6, execucao: 'Padrão', alcance: 'Pessoal', duracao: 'Cena', alvo: 'Você', efeito: 'Você se transforma em uma besta: +5 em Força, Vigor e Agilidade. Recebe RD 10.' },
  { id: 's11', nome: 'Avatar do Sangue', elemento: Elemento.SANGUE, circulo: 4, custoSanidade: 10, execucao: 'Padrão', alcance: 'Pessoal', duracao: 'Cena', alvo: 'Você', efeito: 'Você se torna a personificação do Sangue. Imunidade a dano físico e cura-se com o sangue derramado ao redor.' },

  // 🔵 CONHECIMENTO
  { id: 'c1', nome: 'Compreensão Paranormal', elemento: Elemento.CONHECIMENTO, circulo: 1, custoSanidade: 1, execucao: 'Padrão', alcance: 'Pessoal', duracao: 'Cena', alvo: 'Você', efeito: 'Você consegue ler e entender qualquer idioma ou código.' },
  { id: 'c3', nome: 'Ouvir Sussurros', elemento: Elemento.CONHECIMENTO, circulo: 1, custoSanidade: 1, execucao: 'Padrão', alcance: 'Pessoal', duracao: 'Cena', alvo: 'Você', efeito: 'Sussurros do Outro Lado te dão +5 em testes de Investigação e Percepção.' },
  { id: 'c6', nome: 'Aprimorar Intelecto', elemento: Elemento.CONHECIMENTO, circulo: 2, custoSanidade: 3, execucao: 'Padrão', alcance: 'Toque', duracao: 'Cena', alvo: '1 ser', efeito: 'O alvo recebe +2 em Intelecto e Presença.' },
  { id: 'c8', nome: 'Controle Mental', elemento: Elemento.CONHECIMENTO, circulo: 3, custoSanidade: 6, execucao: 'Padrão', alcance: 'Médio', duracao: 'Cena', alvo: '1 ser', efeito: 'Você implanta comandos na mente do alvo.' },
  { id: 'c11', nome: 'Verdade Absoluta', elemento: Elemento.CONHECIMENTO, circulo: 4, custoSanidade: 10, execucao: 'Padrão', alcance: 'Curto', duracao: 'Instantânea', alvo: '1 ser', efeito: 'O alvo é bombardeado por todo o conhecimento do universo.' },

  // ⚫ MORTE
  { id: 'm1', nome: 'Amaldiçoar Arma', elemento: Elemento.MORTE, circulo: 1, custoSanidade: 1, execucao: 'Padrão', alcance: 'Toque', duracao: 'Cena', alvo: '1 arma', efeito: 'A arma causa +1d6 de dano de Morte.' },
  { id: 'm3', nome: 'Definhar', elemento: Elemento.MORTE, circulo: 1, custoSanidade: 1, execucao: 'Padrão', alcance: 'Médio', duracao: 'Cena', alvo: '1 ser', efeito: 'O alvo fica Fraco e sofre -2 em testes de ataque e Defesa.' },
  { id: 'm5', nome: 'Decadência', elemento: Elemento.MORTE, circulo: 2, custoSanidade: 3, execucao: 'Padrão', alcance: 'Toque', duracao: 'Instantânea', alvo: '1 ser', efeito: 'Toque que envelhece o alvo. Causa 6d6 de dano de Morte.' },
  { id: 'm8', nome: 'Marca da Morte', elemento: Elemento.MORTE, circulo: 3, custoSanidade: 6, execucao: 'Padrão', alcance: 'Médio', duracao: 'Cena', alvo: '1 ser', efeito: 'Todo dano que o alvo sofrer é dobrado enquanto marcado.' },
  { id: 'm11', nome: 'Morte Instantânea', elemento: Elemento.MORTE, circulo: 4, custoSanidade: 10, execucao: 'Padrão', alcance: 'Médio', duracao: 'Instantânea', alvo: '1 ser', efeito: 'O alvo deve passar em um teste de Fortitude ou seu tempo acaba.' },

  // 🟣 ENERGIA
  { id: 'e1', nome: 'Aprimorar Reflexos', elemento: Elemento.ENERGIA, circulo: 1, custoSanidade: 1, execucao: 'Padrão', alcance: 'Toque', duracao: 'Cena', alvo: '1 ser', efeito: 'O alvo recebe +2 em Agilidade e Reflexos.' },
  { id: 'e3', nome: 'Eletrocussão', elemento: Elemento.ENERGIA, circulo: 1, custoSanidade: 1, execucao: 'Padrão', alcance: 'Curto', duracao: 'Instantânea', alvo: '1 ser', efeito: 'Descarga elétrica que causa 3d6 de dano de Energia.' },
  { id: 'e9', nome: 'Distorção Temporal', elemento: Elemento.ENERGIA, circulo: 3, custoSanidade: 6, execucao: 'Padrão', alcance: 'Pessoal', duracao: 'Instantânea', alvo: 'Você', efeito: 'Você volta no tempo 1 rodada.' },
  { id: 'e10', nome: 'Colapso Energético', elemento: Elemento.ENERGIA, circulo: 4, custoSanidade: 10, execucao: 'Padrão', alcance: 'Médio', duracao: 'Instantânea', alvo: 'Área', efeito: 'A realidade se rasga em energia pura. Causa 15d8 de dano.' }
];

export const DEFAULT_CREATURES: Criatura[] = [
  // 🔴 SANGUE
  { id: 'bs1', nome: 'Zumbi de Sangue', elemento: Elemento.SANGUE, vd: 10, vida: 25, defesa: 12, resistencias: 'Dano físico 5', atributos: { FOR: 2, AGI: 1, INT: 0, PRE: 1, VIG: 2 }, pericias: [], ataques: [{ nome: 'Mordida', teste: '1d20+3', dano: '1d6+2', alcance: 'Adjacente', tipo: 'Perfuração' }], habilidades: 'Olfato Apurado', passivas: 'Lento', descricao: 'Morto-vivo básico de sangue.' },
  { id: 'bs2', nome: 'Zumbi de Sangue Bestial', elemento: Elemento.SANGUE, vd: 20, vida: 45, defesa: 14, resistencias: 'Dano físico 10', atributos: { FOR: 3, AGI: 2, INT: 0, PRE: 1, VIG: 3 }, pericias: [], ataques: [{ nome: 'Garras', teste: '1d20+7', dano: '1d10+3', alcance: 'Adjacente', tipo: 'Corte' }], habilidades: 'Frenesi', passivas: 'Faro para Sangue', descricao: 'Uma versão mais agressiva e rápida.' },
  { id: 'bs3', nome: 'Criatura Bestial', elemento: Elemento.SANGUE, vd: 40, vida: 85, defesa: 18, resistencias: 'Dano físico 15', atributos: { FOR: 4, AGI: 3, INT: 1, PRE: 2, VIG: 4 }, pericias: [], ataques: [{ nome: 'Mordida Voraz', teste: '1d20+12', dano: '2d8+5', alcance: 'Adjacente', tipo: 'Perfuração' }], habilidades: 'Salto Brutal', passivas: 'Regeneração de Sangue', descricao: 'Uma besta quadrúpede de puro músculo.' },
  { id: 'bs4', nome: 'Aberração de Carne', elemento: Elemento.SANGUE, vd: 60, vida: 140, defesa: 20, resistencias: 'Físico 20, Balístico 10', atributos: { FOR: 5, AGI: 1, INT: 1, PRE: 2, VIG: 5 }, pericias: [], ataques: [{ nome: 'Esmagar', teste: '1d20+15', dano: '3d10+10', alcance: 'Adjacente', tipo: 'Impacto' }], habilidades: 'Massa Protetora', passivas: 'Lentidão Extrema', descricao: 'Um amontoado de corpos fundidos.' },
  { id: 'bs8', nome: 'Carnífice', elemento: Elemento.SANGUE, vd: 100, vida: 280, defesa: 25, resistencias: 'Geral 20', atributos: { FOR: 5, AGI: 4, INT: 2, PRE: 3, VIG: 5 }, pericias: [], ataques: [{ nome: 'Ganchos', teste: '1d20+20', dano: '4d12+15', alcance: 'Curto', tipo: 'Corte' }], habilidades: 'Gancho Atraidor', passivas: 'Aura de Sangue', descricao: 'O terror dos campos de batalha.' },
  { id: 'bs11', nome: 'Avatar de Sangue', elemento: Elemento.SANGUE, vd: 400, vida: 1200, defesa: 40, resistencias: 'Imunidade Física', atributos: { FOR: 8, AGI: 6, INT: 4, PRE: 6, VIG: 8 }, pericias: [], ataques: [{ nome: 'Golpe do Fim', teste: '1d20+35', dano: '10d12', alcance: 'Médio', tipo: 'Sangue' }], habilidades: 'Domínio do Sangue', passivas: 'Entidade Suprema', descricao: 'A encarnação máxima do elemento.' },

  // 🔵 CONHECIMENTO
  { id: 'bc1', nome: 'Anjo', elemento: Elemento.CONHECIMENTO, vd: 80, vida: 150, defesa: 22, resistencias: 'Conhecimento 20', atributos: { FOR: 3, AGI: 3, INT: 5, PRE: 5, VIG: 3 }, pericias: [], ataques: [{ nome: 'Lança de Luz', teste: '1d20+15', dano: '3d8+10', alcance: 'Longo', tipo: 'Conhecimento' }], habilidades: 'Julgamento', passivas: 'Voo', descricao: 'Entidade de geometria impossível.' },
  { id: 'bc3', nome: 'O Espreitador', elemento: Elemento.CONHECIMENTO, vd: 40, vida: 90, defesa: 18, resistencias: 'Furtividade +15', atributos: { FOR: 2, AGI: 5, INT: 4, PRE: 4, VIG: 2 }, pericias: [], ataques: [{ nome: 'Toque da Mente', teste: '1d20+12', dano: '2d10', alcance: 'Médio', tipo: 'Mental' }], habilidades: 'Invisibilidade', passivas: 'Observador Silencioso', descricao: 'Sempre vigiando, nunca visto.' },
  { id: 'bc5', nome: 'O Ceifador do Conhecimento', elemento: Elemento.CONHECIMENTO, vd: 160, vida: 350, defesa: 30, resistencias: 'Mental 30', atributos: { FOR: 4, AGI: 4, INT: 7, PRE: 6, VIG: 4 }, pericias: [], ataques: [{ nome: 'Foice de Ideias', teste: '1d20+25', dano: '5d10+15', alcance: 'Médio', tipo: 'Corte' }], habilidades: 'Apagar Memória', passivas: 'Aura Opressora', descricao: 'Aquele que coleta o que você sabe.' },

  // ⚫ MORTE
  { id: 'bm1', nome: 'Zumbi de Morte', elemento: Elemento.MORTE, vd: 10, vida: 20, defesa: 10, resistencias: 'Morte 10', atributos: { FOR: 1, AGI: 1, INT: 0, PRE: 1, VIG: 2 }, pericias: [], ataques: [{ nome: 'Toque Gelado', teste: '1d20+4', dano: '1d8', alcance: 'Adjacente', tipo: 'Morte' }], habilidades: 'Abraço Entrópico', passivas: 'Lodo', descricao: 'Consumido pelo tempo.' },
  { id: 'bm4', nome: 'O Ceifador', elemento: Elemento.MORTE, vd: 100, vida: 240, defesa: 26, resistencias: 'Morte 20', atributos: { FOR: 5, AGI: 4, INT: 3, PRE: 4, VIG: 4 }, pericias: [], ataques: [{ nome: 'Lâmina de Lodo', teste: '1d20+22', dano: '4d10+10', alcance: 'Médio', tipo: 'Corte' }], habilidades: 'Ceifar Vida', passivas: 'Rastro de Lodo', descricao: 'O executor da entropia.' },
  { id: 'bm9', nome: 'Arauto da Morte', elemento: Elemento.MORTE, vd: 280, vida: 600, defesa: 35, resistencias: 'Morte 40', atributos: { FOR: 4, AGI: 4, INT: 5, PRE: 8, VIG: 5 }, pericias: [], ataques: [{ nome: 'Grito do Fim', teste: 'DT 35 Vontade', dano: '8d10', alcance: 'Longo', tipo: 'Morte' }], habilidades: 'Sentença', passivas: 'Imortalidade Relativa', descricao: 'A voz que anuncia o fim de tudo.' },

  // 🟣 ENERGIA
  { id: 'be1', nome: 'Poltergeist', elemento: Elemento.ENERGIA, vd: 20, vida: 40, defesa: 16, resistencias: 'Dano físico (imune)', atributos: { FOR: 0, AGI: 4, INT: 2, PRE: 3, VIG: 2 }, pericias: [], ataques: [{ nome: 'Arremessar Objeto', teste: '1d20+8', dano: '1d12+4', alcance: 'Médio', tipo: 'Impacto' }], habilidades: 'Telecinésia', passivas: 'Incorpóreo', descricao: 'Espírito instável de pura energia.' },
  { id: 'be5', nome: 'Entidade Caótica', elemento: Elemento.ENERGIA, vd: 120, vida: 250, defesa: 28, resistencias: 'Energia 30', atributos: { FOR: 3, AGI: 6, INT: 4, PRE: 5, VIG: 4 }, pericias: [], ataques: [{ nome: 'Raio de Caos', teste: '1d20+24', dano: '6d8', alcance: 'Longo', tipo: 'Energia' }], habilidades: 'Teletransporte', passivas: 'Distorção', descricao: 'Um erro na programação da realidade.' }
];

export const DEFAULT_NPCS: NPC[] = [
  // Liderança e Figuras Centrais
  // Providing full Atributos objects to satisfy type system requirements
  { id: 'n1', nome: 'Senhor Veríssimo', funcao: 'Líder da Ordem', personalidade: 'Estóico e estratégico.', medos: 'A queda da Ordem.', segredos: 'O peso das decisões.', atributos: { FOR: 1, AGI: 1, INT: 5, PRE: 5, VIG: 1 }, pericias: 'Diplomacia, Tática', corrupcao: 'Proteção Antiga' },
  { id: 'n2', nome: 'Dante', funcao: 'Intelectual da Ordem', personalidade: 'Frio e analítico.', medos: 'A ignorância.', segredos: 'Ligação com o Conhecimento.', atributos: { FOR: 1, AGI: 1, INT: 6, PRE: 4, VIG: 1 }, pericias: 'Ocultismo, Ciências', corrupcao: 'Símbolos Marcados' },
  { id: 'n3', nome: 'Elizabeth Webber', funcao: 'Agente de Alto Nível', personalidade: 'Eficiente e corajosa.', medos: 'Perder a equipe.', segredos: 'Missões confidenciais.', atributos: { FOR: 3, AGI: 4, INT: 3, PRE: 1, VIG: 1 }, pericias: 'Investigação, Pontaria', corrupcao: 'Nenhuma' },
  { id: 'n4', nome: 'Alexandre', funcao: 'Membro Antigo', personalidade: 'Leal e experiente.', medos: 'O esquecimento.', segredos: 'Rituais proibidos.', atributos: { FOR: 4, AGI: 1, INT: 1, PRE: 1, VIG: 4 }, pericias: 'Luta, Sobrevivência', corrupcao: 'Toque da Morte' },
  { id: 'n5', nome: 'Arnaldo Fritz', funcao: 'Cientista e Pesquisador', personalidade: 'Obsessivo e brilhante.', medos: 'A falta de dados.', segredos: 'Experimentos de lodo.', atributos: { FOR: 1, AGI: 1, INT: 5, PRE: 1, VIG: 1 }, pericias: 'Tecnologia, Medicina', corrupcao: 'Nenhuma' },
  
  // Agentes e Funcionários
  { id: 'n8', nome: 'Thiago Fritz', funcao: 'Agente Veterano', personalidade: 'Protetor e impulsivo.', medos: 'Perder a família.', segredos: 'Traumas de campo.', atributos: { FOR: 4, AGI: 1, INT: 1, PRE: 1, VIG: 4 }, pericias: 'Luta, Atletismo', corrupcao: 'Nenhuma' },
  { id: 'n9', nome: 'Beatrice', funcao: 'Agente Especialista', personalidade: 'Calma e observadora.', medos: 'O silêncio.', segredos: 'Conexão paranormal.', atributos: { FOR: 1, AGI: 5, INT: 1, PRE: 4, VIG: 1 }, pericias: 'Furtividade, Ocultismo', corrupcao: 'Veias Escurecidas' },
  { id: 'n10', nome: 'Júlio', funcao: 'Agente e Técnico', personalidade: 'Prático e focado.', medos: 'Falha técnica.', segredos: 'Equipamentos ilegais.', atributos: { FOR: 1, AGI: 3, INT: 4, PRE: 1, VIG: 1 }, pericias: 'Tecnologia, Pilotagem', corrupcao: 'Nenhuma' },
  { id: 'n13', nome: 'Equipe de Médicos/Analistas', funcao: 'Suporte da Ordem', personalidade: 'Resilientes.', medos: 'Contaminação.', segredos: 'Arquivos restritos.', atributos: { FOR: 1, AGI: 1, INT: 4, PRE: 1, VIG: 1 }, pericias: 'Medicina, Investigação', corrupcao: 'Nenhuma' }
];

export const DEFAULT_VILLAINS: Vilao[] = [
  // 🧠 Antagonistas Humanos e Ocultistas
  { 
    id: 'v1', 
    nome: 'Kian', 
    elemento: Elemento.MEDO, 
    vd: 400, 
    nex: 99, 
    classe: Classe.OCULTISTA, 
    trilha: 'O Primeiro Ocultista', 
    vida: 1000, 
    defesa: 45, 
    resistencias: 'Imunidade Geral', 
    sanidade: 100, 
    atributos: { FOR: 4, AGI: 4, INT: 10, PRE: 8, VIG: 6 }, 
    pericias: [], 
    ataques: [{ nome: 'Palavra Primordial', teste: 'Auto', dano: '10d10', alcance: 'Longo', tipo: 'Medo' }], 
    rituais: ['Todos'], 
    objetosAmaldiçoados: 'Corpo Imortal', 
    fraquezas: 'Desconhecidas', 
    habilidades: 'Reescrita da Realidade', 
    passivas: 'Transcendido', 
    descricao: 'A maior ameaça humana. Aquele que sabe de tudo.', 
    isBoss: true 
  },
  { 
    id: 'v2', 
    nome: 'Gal', 
    elemento: Elemento.MORTE, 
    vd: 240, 
    nex: 80, 
    classe: Classe.OCULTISTA, 
    trilha: 'Flagelador', 
    vida: 450, 
    defesa: 32, 
    resistencias: 'Morte 40', 
    sanidade: 0, 
    atributos: { FOR: 3, AGI: 3, INT: 6, PRE: 5, VIG: 5 }, 
    pericias: [], 
    ataques: [{ nome: 'Lâmina de Morte', teste: '1d20+25', dano: '4d10+10', alcance: 'Curto', tipo: 'Morte' }], 
    rituais: ['Definhar', 'Morte Instantânea'], 
    objetosAmaldiçoados: 'Máscara de Gal', 
    fraquezas: 'Luz Pura', 
    habilidades: 'Mão de Lodo', 
    passivas: 'Aura de Envelhecimento', 
    descricao: 'O braço direito de Kian. Um mestre da entropia.', 
    isBoss: true 
  },
  { 
    id: 'v3', 
    nome: 'Ocultistas da Desconjuração', 
    elemento: Elemento.CONHECIMENTO, 
    vd: 60, 
    nex: 35, 
    classe: Classe.OCULTISTA, 
    trilha: 'Graduado', 
    vida: 90, 
    defesa: 18, 
    resistencias: 'Mental 10', 
    sanidade: 20, 
    atributos: { FOR: 1, AGI: 1, INT: 5, PRE: 4, VIG: 1 }, 
    pericias: [], 
    ataques: [{ nome: 'Adaga Ritual', teste: '1d20+12', dano: '1d6+4', alcance: 'Toque', tipo: 'Perfuração' }], 
    rituais: ['Perturbação', 'Eco Doloroso'], 
    objetosAmaldiçoados: 'Símbolos de Conhecimento', 
    fraquezas: 'Dano Físico', 
    habilidades: 'Conjuração Rápida', 
    passivas: 'Fanatismo', 
    descricao: 'Seguidores da causa de Kian.', 
    isBoss: false 
  },
  
  // 🧿 Humanos Alterados
  // Filling missing attributes for villains to satisfy Criatura interface (which Vilao extends)
  { id: 'v5', nome: 'Marcado', elemento: Elemento.MEDO, vd: 40, nex: 15, classe: Classe.ESPECIALISTA, trilha: 'Infiltrador', vida: 60, defesa: 16, resistencias: 'Geral 5', sanidade: 15, atributos: { FOR: 1, AGI: 4, INT: 3, PRE: 1, VIG: 1 }, pericias: [], ataques: [{ nome: 'Revólver', teste: '1d20+8', dano: '2d6', alcance: 'Médio', tipo: 'Perfuração' }], rituais: [], objetosAmaldiçoados: 'A Marca', fraquezas: 'Desconexão', habilidades: 'Sorte Paranormal', passivas: 'Destino Traçado', descricao: 'Alguém que foi tocado pelo Outro Lado.', isBoss: false },
  { id: 'v6', nome: 'Possuído', elemento: Elemento.ENERGIA, vd: 50, nex: 20, classe: Classe.COMBATENTE, trilha: 'Guerreiro', vida: 110, defesa: 20, resistencias: 'Energia 20', sanidade: 0, atributos: { FOR: 4, AGI: 1, INT: 1, PRE: 1, VIG: 4 }, pericias: [], ataques: [{ nome: 'Pancada Vibrante', teste: '1d20+12', dano: '2d10+8', alcance: 'Toque', tipo: 'Energia' }], rituais: [], objetosAmaldiçoados: 'Nenhum', fraquezas: 'Exorcismo', habilidades: 'Surto Caótico', passivas: 'Mente Fragmentada', descricao: 'O corpo é apenas um hospedeiro.', isBoss: false }
];

export const DEFAULT_WEAPONS: Arma[] = [
  { id: 'w1', nome: 'Faca', tipo: TipoArma.BRANCA, dano: '1d4', critico: '19/x2', alcance: 'Curto', espaco: 1, categoria: 0, descricao: 'Uma lâmina pequena e versátil.' },
  { id: 'w7', nome: 'Pistola', tipo: TipoArma.FOGO, dano: '1d12', critico: '18/x2', alcance: 'Curto', espaco: 1, categoria: 1, descricao: 'Arma semiautomática padrão.' },
  { id: 'w8', nome: 'Fuzil de Assalto', tipo: TipoArma.FOGO, dano: '2d10', critico: '19/x3', alcance: 'Médio', espaco: 2, categoria: 2, descricao: 'Arma pesada para combate intenso.' }
];
