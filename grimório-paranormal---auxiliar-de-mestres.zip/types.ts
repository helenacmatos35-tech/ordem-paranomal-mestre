
export enum Elemento {
  SANGUE = 'Sangue',
  MORTE = 'Morte',
  CONHECIMENTO = 'Conhecimento',
  ENERGIA = 'Energia',
  MEDO = 'Medo'
}

export enum Classe {
  COMBATENTE = 'Combatente',
  ESPECIALISTA = 'Especialista',
  OCULTISTA = 'Ocultista'
}

export enum EstadoMembrana {
  ESTAVEL = 'Estável',
  FINA = 'Fina',
  DANIFICADA = 'Danificada',
  ROMPIDA = 'Rompida'
}

export enum Patente {
  RECRUTA = 'Recruta',
  OPERADOR = 'Operador',
  AGENTE_ESPECIAL = 'Agente Especial',
  OFFICIAL_DE_OPERACOES = 'Oficial de Operações',
  AGENTE_DE_ELITE = 'Agente de Elite'
}

export interface Atributos {
  FOR: number;
  AGI: number;
  INT: number;
  PRE: number;
  VIG: number;
}

export interface Pericia {
  nome: string;
  bonus: number;
}

export interface Ataque {
  nome: string;
  teste: string;
  dano: string;
  alcance: string;
  tipo: string;
}

export interface Criatura {
  id: string;
  nome: string;
  elemento: Elemento;
  vd: number;
  vida: number;
  defesa: number;
  resistencias: string;
  atributos: Atributos;
  pericias: Pericia[];
  ataques: Ataque[];
  habilidades: string;
  passivas: string;
  descricao: string;
}

export interface Ritual {
  id: string;
  nome: string;
  elemento: Elemento;
  circulo: 1 | 2 | 3 | 4;
  custoSanidade: number;
  execucao: string;
  alcance: string;
  duracao: string;
  alvo: string;
  efeito: string;
  falhaCritica?: string;
  versaoAprimorada?: string;
}

export interface NPC {
  id: string;
  nome: string;
  funcao: string;
  personalidade: string;
  medos: string;
  segredos: string;
  atributos: Partial<Atributos>;
  pericias: string;
  corrupcao: string;
}

export interface Vilao extends Criatura {
  nex: number;
  classe: Classe;
  trilha: string;
  sanidade: number;
  rituais: string[];
  objetosAmaldiçoados: string;
  fraquezas: string;
  isBoss: boolean;
}

export interface LogDados {
  timestamp: string;
  formula: string;
  resultado: number;
  detalhes: string;
  secret: boolean;
}

export interface Pista {
  id: string;
  titulo: string;
  descricao: string;
  encontrada: boolean;
}

export interface ParticipanteCombate {
  id: string;
  nome: string;
  iniciativa: number;
  vidaAtual: number;
  vidaMaxima: number;
  isPlayer: boolean;
  condicoes: string[];
}

export enum TipoArma {
  BRANCA = 'Branca',
  FOGO = 'Fogo'
}

export interface Arma {
  id: string;
  nome: string;
  tipo: TipoArma;
  dano: string;
  critico: string;
  alcance: string;
  espaco: number;
  categoria: number;
  descricao: string;
}

export interface Cena {
  id: string;
  titulo: string;
  descricao: string;
  ameaca: string;
  objetivo: string;
  pistasIds: string[];
}

export interface Missao {
  id: string;
  titulo: string;
  resumo: string;
  cenas: Cena[];
  localizacao: string;
}

export interface Condicao {
  nome: string;
  efeito: string;
  penalidade: string;
}

export interface Localidade {
  id: string;
  nome: string;
  descricao: string;
  estadoMembrana: EstadoMembrana;
  pistasIds: string[];
  perigos: string;
}
