
import { GoogleGenAI } from "@google/genai";
import { Elemento } from './types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function gerarDescricaoCriatura(nome: string, elemento: Elemento, vd: number) {
  const prompt = `Como um mestre de Ordem Paranormal, descreva a aparência e o comportamento de uma criatura chamada "${nome}". Elemento: ${elemento}. VD: ${vd}. Foco em horror e mecânicas narrativas.`;
  const response = await ai.models.generateContent({ model: 'gemini-3-flash-preview', contents: prompt });
  return response.text;
}

export async function sugerirMisterio() {
  const prompt = `Gere uma premissa de mistério para Ordem Paranormal RPG: Local, Evento Inicial, Elemento e 3 pistas chave.`;
  const response = await ai.models.generateContent({ model: 'gemini-3-flash-preview', contents: prompt });
  return response.text;
}

export async function sugerirEfeitoRitual(nome: string, elemento: Elemento) {
  const prompt = `Crie o efeito de um ritual paranormal chamado "${nome}" do elemento ${elemento} para o RPG Ordem Paranormal. Inclua o efeito mecânico e a descrição visual perturbadora.`;
  const response = await ai.models.generateContent({ model: 'gemini-3-flash-preview', contents: prompt });
  return response.text;
}

export async function gerarSegredoNPC(nome: string, funcao: string) {
  const prompt = `Crie um segredo sombrio ou uma ligação paranormal para um NPC chamado "${nome}" que atua como "${funcao}" em uma campanha de Ordem Paranormal.`;
  const response = await ai.models.generateContent({ model: 'gemini-3-flash-preview', contents: prompt });
  return response.text;
}

export async function gerarCenaParanormal(elemento: Elemento) {
  const prompt = `Descreva uma cena de horror curta e impactante baseada no elemento ${elemento} de Ordem Paranormal. Foque em sensações táteis, visuais e no medo instintivo.`;
  const response = await ai.models.generateContent({ model: 'gemini-3-flash-preview', contents: prompt });
  return response.text;
}

export async function gerarItemAmaldicoado(elemento: Elemento) {
  const prompt = `Crie um item amaldiçoado do elemento ${elemento} para Ordem Paranormal RPG. Inclua: Nome, Descrição visual, Bônus mecânico, e o Efeito Colateral (Custo de Sanidade ou penalidade).`;
  const response = await ai.models.generateContent({ model: 'gemini-3-flash-preview', contents: prompt });
  return response.text;
}

export async function descreverAmbiente(tipo: string) {
  const prompt = `Descreva um ambiente de ${tipo} para uma sessão de Ordem Paranormal. O ambiente deve ser opressor, detalhado e conter elementos que sugiram a influência do paranormal.`;
  const response = await ai.models.generateContent({ model: 'gemini-3-flash-preview', contents: prompt });
  return response.text;
}

export async function gerarReviravolta(elemento: Elemento, contexto: string) {
  const prompt = `O mestre de Ordem Paranormal precisa de uma reviravolta (Plot Twist) chocante. Contexto atual: ${contexto}. Elemento predominante: ${elemento}. A reviravolta deve ser trágica, paranormal e mudar o rumo da investigação.`;
  const response = await ai.models.generateContent({ model: 'gemini-3-flash-preview', contents: prompt });
  return response.text;
}

export async function gerarIdentidadeVitima() {
  const prompt = `Gere uma identidade para uma vítima ou NPC aleatório em Ordem Paranormal: Nome completo, Profissão, um Objeto de Valor pessoal e um "Último Registro" (uma frase dita ou escrita antes de algo ruim acontecer).`;
  const response = await ai.models.generateContent({ model: 'gemini-3-flash-preview', contents: prompt });
  return response.text;
}
